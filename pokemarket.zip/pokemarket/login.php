<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>PokéMarket</title>

    <link rel="stylesheet" href="assets/css/base.css">
    <link rel="stylesheet" href="assets/css/auth.css">

</head>

<body>

<div class="auth-page">

    <main class="auth-layout">


        <section class="auth-hero">


            <div class="brand">

                <div class="brand-ball"></div>

                <div class="brand-name">

                    <span class="brand-poke">
                        Poké
                    </span><span class="brand-market">Market</span>

                </div>

            </div>


            <div class="hero-copy">

                <h1>
                    Tu colección
                    comienza <strong>aquí</strong>
                </h1>

                <p>
                    Explora diferentes Pokémon,
                    consulta sus características
                    y crea tu propia colección personal.
                </p>

            </div>


            <div class="preview-cards">


                <article class="preview-card">

                    <img
                        src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png"
                        alt="Bulbasaur">

                    <div class="preview-card-info">

                        <strong>Bulbasaur</strong>

                        <span>
                            Grass · Poison
                        </span>

                    </div>

                </article>


                <article class="preview-card">

                    <img
                        src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png"
                        alt="Charmander">

                    <div class="preview-card-info">

                        <strong>Charmander</strong>

                        <span>
                            Fire
                        </span>

                    </div>

                </article>


                <article class="preview-card">

                    <img
                        src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png"
                        alt="Pikachu">

                    <div class="preview-card-info">

                        <strong>Pikachu</strong>

                        <span>
                            Electric
                        </span>

                    </div>

                </article>

            </div>


            <div class="hero-features">


                <div class="hero-feature">

                    <div class="feature-icon">

                        <svg
                            viewBox="0 0 24 24"
                            aria-hidden="true">

                            <circle
                                cx="11"
                                cy="11"
                                r="6">
                            </circle>

                            <path
                                d="M16 16l4 4">
                            </path>

                        </svg>

                    </div>

                    <div class="feature-content">

                        <strong>
                            Explora
                        </strong>

                        <span>
                            Encuentra diferentes Pokémon.
                        </span>

                    </div>

                </div>


                <div class="hero-feature">

                    <div class="feature-icon">

                        <svg
                            viewBox="0 0 24 24"
                            aria-hidden="true">

                            <circle
                                cx="12"
                                cy="12"
                                r="9">
                            </circle>

                            <path
                                d="M12 10v6">
                            </path>

                            <path
                                d="M12 7h.01">
                            </path>

                        </svg>

                    </div>

                    <div class="feature-content">

                        <strong>
                            Descubre
                        </strong>

                        <span>
                            Conoce sus características.
                        </span>

                    </div>

                </div>


                <div class="hero-feature">

                    <div class="feature-icon">

                        <svg
                            viewBox="0 0 24 24"
                            aria-hidden="true">

                            <path
                                d="M6 4h12a2 2 0 0 1 2 2v14l-8-4-8 4V6a2 2 0 0 1 2-2z">
                            </path>

                        </svg>

                    </div>

                    <div class="feature-content">

                        <strong>
                            Colecciona
                        </strong>

                        <span>
                            Guarda tus Pokémon favoritos.
                        </span>

                    </div>

                </div>

            </div>

        </section>


        <section class="auth-panel">

            <div class="auth-card">


                <div class="auth-symbol"></div>


                <h2>
                    Iniciar sesión
                </h2>


                <p class="auth-description">

                    Bienvenido de nuevo.
                    Ingresa tus datos para continuar.

                </p>


                <div
                    id="mensaje"
                    class="form-message">
                </div>


                <form id="formLogin">


                    <div class="form-group">

                        <label for="email">
                            Correo electrónico
                        </label>

                        <input
                            class="form-control"
                            type="email"
                            id="email"
                            placeholder="ejemplo@correo.com"
                            required>

                    </div>


                    <div class="form-group">

                        <label for="password">
                            Contraseña
                        </label>

                        <input
                            class="form-control"
                            type="password"
                            id="password"
                            placeholder="Ingresa tu contraseña"
                            required>

                    </div>


                    <button
                        class="btn-primary"
                        type="submit">

                        Iniciar sesión

                    </button>

                </form>


                <p class="auth-switch">

                    ¿Aún no tienes cuenta?

                    <a href="registro.php">
                        Crear cuenta
                    </a>

                </p>


            </div>

        </section>


    </main>

</div>


<script src="assets/js/api.js"></script>
<script src="assets/js/login.js"></script>

</body>

</html>
