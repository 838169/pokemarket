<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);

    exit;
}

$datos = json_decode(
    file_get_contents("php://input"),
    true
);

$email = trim($datos["email"] ?? "");
$password = $datos["password"] ?? "";


if ($email === "" || $password === "") {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Correo y contraseña son obligatorios"
    ]);

    exit;
}


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "El correo no es válido"
    ]);

    exit;
}


try {

    $consulta = $conexion->prepare(
        "SELECT id, nombre, email, password
         FROM usuarios
         WHERE email = :email
         LIMIT 1"
    );

    $consulta->execute([
        ":email" => $email
    ]);

    $usuario = $consulta->fetch(PDO::FETCH_ASSOC);


    if (
        !$usuario ||
        !password_verify(
            $password,
            $usuario["password"]
        )
    ) {

        http_response_code(401);

        echo json_encode([
            "success" => false,
            "message" => "Correo o contraseña incorrectos"
        ]);

        exit;
    }


    // Evita reutilizar el identificador
    // de sesión anterior.
    session_regenerate_id(true);


    $_SESSION["usuario_id"] =
        $usuario["id"];

    $_SESSION["usuario_nombre"] =
        $usuario["nombre"];

    $_SESSION["usuario_email"] =
        $usuario["email"];


    echo json_encode([
        "success" => true,
        "message" => "Inicio de sesión correcto",
        "usuario" => [
            "id" => $usuario["id"],
            "nombre" => $usuario["nombre"]
        ]
    ]);

}
catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error interno del servidor"
    ]);
}