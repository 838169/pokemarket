<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Usuario no autenticado"
    ]);

    exit;
}

$usuarioId = $_SESSION["usuario_id"];

try {

    $consulta = $conexion->prepare(
        "SELECT
            id,
            pokemon_id,
            pokemon_nombre,
            fecha_agregado
         FROM coleccion
         WHERE usuario_id = :usuario_id
         ORDER BY fecha_agregado DESC"
    );

    $consulta->execute([
        ":usuario_id" => $usuarioId
    ]);

    $coleccion =
        $consulta->fetchAll(
            PDO::FETCH_ASSOC
        );

    echo json_encode([
        "success" => true,
        "total" => count($coleccion),
        "coleccion" => $coleccion
    ]);

}
catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible consultar la colección"
    ]);
}