<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Usuario no autenticado"
    ]);

    exit;
}

$limit = isset($_GET["limit"])
    ? intval($_GET["limit"])
    : 6;

$offset = isset($_GET["offset"])
    ? intval($_GET["offset"])
    : 0;

if ($limit < 1 || $limit > 20) {
    $limit = 6;
}

if ($offset < 0) {
    $offset = 0;
}

$cacheDir = __DIR__ . "/../cache";

if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

$cacheFile =
    $cacheDir .
    "/pokemon_" .
    $offset .
    "_" .
    $limit .
    ".json";

$cacheTiempo = 900;

if (
    file_exists($cacheFile) &&
    (time() - filemtime($cacheFile)) < $cacheTiempo
) {
    echo file_get_contents($cacheFile);
    exit;
}

function consultarApi($url)
{
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $respuesta = curl_exec($curl);

    $codigoHttp =
        curl_getinfo(
            $curl,
            CURLINFO_HTTP_CODE
        );

    curl_close($curl);

    if (
        $respuesta === false ||
        $codigoHttp !== 200
    ) {
        return null;
    }

    return json_decode(
        $respuesta,
        true
    );
}

$urlLista =
    "https://pokeapi.co/api/v2/pokemon"
    . "?limit={$limit}"
    . "&offset={$offset}";

$lista = consultarApi($urlLista);

if (
    !$lista ||
    !isset($lista["results"])
) {
    http_response_code(502);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible consultar PokéAPI"
    ]);

    exit;
}

$multiCurl = curl_multi_init();

$handles = [];

foreach ($lista["results"] as $indice => $pokemon) {

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => $pokemon["url"],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    curl_multi_add_handle(
        $multiCurl,
        $curl
    );

    $handles[$indice] = $curl;
}

do {

    $estado =
        curl_multi_exec(
            $multiCurl,
            $activo
        );

    if ($activo) {
        curl_multi_select(
            $multiCurl,
            1
        );
    }

} while (
    $activo &&
    $estado === CURLM_OK
);

$pokemonResultado = [];

foreach ($handles as $curl) {

    $contenido =
        curl_multi_getcontent(
            $curl
        );

    $codigoHttp =
        curl_getinfo(
            $curl,
            CURLINFO_HTTP_CODE
        );

    if (
        $codigoHttp === 200 &&
        $contenido
    ) {

        $detalle =
            json_decode(
                $contenido,
                true
            );

        if ($detalle) {

            $tipos = [];

            foreach (
                $detalle["types"]
                as $tipo
            ) {

                $tipos[] =
                    $tipo["type"]["name"];
            }

            $imagen =
                $detalle["sprites"]["other"]
                ["official-artwork"]
                ["front_default"]
                ??
                $detalle["sprites"]
                ["front_default"];

            $pokemonResultado[] = [

                "id" =>
                    $detalle["id"],

                "nombre" =>
                    ucfirst(
                        $detalle["name"]
                    ),

                "imagen" =>
                    $imagen,

                "tipos" =>
                    $tipos
            ];
        }
    }

    curl_multi_remove_handle(
        $multiCurl,
        $curl
    );

    curl_close($curl);
}

curl_multi_close(
    $multiCurl
);

usort(
    $pokemonResultado,
    function ($a, $b) {
        return $a["id"] <=> $b["id"];
    }
);

$resultado = json_encode([
    "success" => true,
    "total" => $lista["count"],
    "pokemon" => $pokemonResultado
]);

file_put_contents(
    $cacheFile,
    $resultado
);

echo $resultado;