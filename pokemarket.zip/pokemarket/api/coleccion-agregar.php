<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Usuario no autenticado"
    ]);

    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);

    exit;
}

$datos = json_decode(
    file_get_contents("php://input"),
    true
);

$pokemonId =
    intval(
        $datos["pokemon_id"] ?? 0
    );

$pokemonNombre =
    trim(
        $datos["pokemon_nombre"] ?? ""
    );

$usuarioId =
    $_SESSION["usuario_id"];

if (
    $pokemonId <= 0 ||
    $pokemonNombre === ""
) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Información del Pokémon incompleta"
    ]);

    exit;
}

try {

    $consulta =
        $conexion->prepare(
            "SELECT id
             FROM coleccion
             WHERE usuario_id = :usuario_id
             AND pokemon_id = :pokemon_id"
        );

    $consulta->execute([
        ":usuario_id" => $usuarioId,
        ":pokemon_id" => $pokemonId
    ]);

    if ($consulta->fetch()) {

        echo json_encode([
            "success" => false,
            "already_exists" => true,
            "message" => "Este Pokémon ya está en tu colección"
        ]);

        exit;
    }

    $consulta =
        $conexion->prepare(
            "INSERT INTO coleccion
            (
                usuario_id,
                pokemon_id,
                pokemon_nombre
            )
            VALUES
            (
                :usuario_id,
                :pokemon_id,
                :pokemon_nombre
            )"
        );

    $consulta->execute([
        ":usuario_id" => $usuarioId,
        ":pokemon_id" => $pokemonId,
        ":pokemon_nombre" => $pokemonNombre
    ]);

    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Pokémon agregado a tu colección"
    ]);

}
catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible guardar el Pokémon"
    ]);
}