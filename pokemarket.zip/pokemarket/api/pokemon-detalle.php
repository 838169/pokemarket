<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Usuario no autenticado"
    ]);

    exit;
}

$id = isset($_GET["id"])
    ? intval($_GET["id"])
    : 0;

if ($id <= 0) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Pokémon no válido"
    ]);

    exit;
}

$cacheDir = __DIR__ . "/../cache";

if (!is_dir($cacheDir)) {
    mkdir($cacheDir, 0777, true);
}

$cacheFile =
    $cacheDir .
    "/detalle_" .
    $id .
    ".json";

$cacheTiempo = 900;

if (
    file_exists($cacheFile) &&
    (time() - filemtime($cacheFile)) < $cacheTiempo
) {
    echo file_get_contents($cacheFile);
    exit;
}

function consultarDetalle($url)
{
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true
    ]);

    $respuesta = curl_exec($curl);

    $codigo =
        curl_getinfo(
            $curl,
            CURLINFO_HTTP_CODE
        );

    curl_close($curl);

    if (
        $respuesta === false ||
        $codigo !== 200
    ) {
        return null;
    }

    return json_decode(
        $respuesta,
        true
    );
}

$pokemon =
    consultarDetalle(
        "https://pokeapi.co/api/v2/pokemon/{$id}"
    );

if (!$pokemon) {
    http_response_code(502);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible consultar el Pokémon"
    ]);

    exit;
}

$especie =
    consultarDetalle(
        $pokemon["species"]["url"]
    );

$tipos = [];

foreach ($pokemon["types"] as $tipo) {
    $tipos[] =
        $tipo["type"]["name"];
}

$habilidades = [];

foreach ($pokemon["abilities"] as $habilidad) {
    $habilidades[] = [
        "nombre" =>
            ucfirst(
                str_replace(
                    "-",
                    " ",
                    $habilidad["ability"]["name"]
                )
            ),
        "oculta" =>
            $habilidad["is_hidden"]
    ];
}

$descripcion = "";

if (
    $especie &&
    isset($especie["flavor_text_entries"])
) {
    foreach (
        $especie["flavor_text_entries"]
        as $entrada
    ) {
        if (
            $entrada["language"]["name"]
            === "es"
        ) {
            $descripcion =
                str_replace(
                    ["\n", "\f"],
                    " ",
                    $entrada["flavor_text"]
                );

            break;
        }
    }
}

$imagen =
    $pokemon["sprites"]["other"]
    ["official-artwork"]
    ["front_default"]
    ??
    $pokemon["sprites"]
    ["front_default"];

$resultado = json_encode([
    "success" => true,

    "pokemon" => [
        "id" =>
            $pokemon["id"],

        "nombre" =>
            ucfirst(
                $pokemon["name"]
            ),

        "imagen" =>
            $imagen,

        "tipos" =>
            $tipos,

        "altura" =>
            $pokemon["height"] / 10,

        "peso" =>
            $pokemon["weight"] / 10,

        "habilidades" =>
            $habilidades,

        "descripcion" =>
            $descripcion
    ]
]);

file_put_contents(
    $cacheFile,
    $resultado
);

echo $resultado;