<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Usuario no autenticado"
    ]);

    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "DELETE") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);

    exit;
}

$datos = json_decode(
    file_get_contents("php://input"),
    true
);

$pokemonId =
    intval(
        $datos["pokemon_id"] ?? 0
    );

if ($pokemonId <= 0) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Pokémon no válido"
    ]);

    exit;
}

$usuarioId =
    $_SESSION["usuario_id"];

try {

    $consulta =
        $conexion->prepare(
            "DELETE FROM coleccion
             WHERE usuario_id = :usuario_id
             AND pokemon_id = :pokemon_id"
        );

    $consulta->execute([
        ":usuario_id" => $usuarioId,
        ":pokemon_id" => $pokemonId
    ]);

    if ($consulta->rowCount() === 0) {

        echo json_encode([
            "success" => false,
            "message" => "El Pokémon no estaba en tu colección"
        ]);

        exit;
    }

    echo json_encode([
        "success" => true,
        "message" => "Pokémon eliminado de tu colección"
    ]);

}
catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible eliminar el Pokémon"
    ]);
}