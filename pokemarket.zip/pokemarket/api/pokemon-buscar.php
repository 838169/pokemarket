<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(401);

    echo json_encode([
        "success" => false,
        "message" => "Usuario no autenticado"
    ]);

    exit;
}

$termino =
    strtolower(
        trim(
            $_GET["q"] ?? ""
        )
    );

if ($termino === "") {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Ingresa un nombre o número"
    ]);

    exit;
}

if (!preg_match('/^[a-z0-9-]+$/', $termino)) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Búsqueda no válida"
    ]);

    exit;
}

$cacheDir =
    __DIR__ . "/../cache";

if (!is_dir($cacheDir)) {
    mkdir(
        $cacheDir,
        0777,
        true
    );
}

$cacheFile =
    $cacheDir .
    "/buscar_" .
    md5($termino) .
    ".json";

$cacheTiempo =
    900;

if (
    file_exists($cacheFile) &&
    (time() - filemtime($cacheFile)) < $cacheTiempo
) {
    echo file_get_contents(
        $cacheFile
    );

    exit;
}

$url =
    "https://pokeapi.co/api/v2/pokemon/"
    . rawurlencode($termino);

$curl =
    curl_init();

curl_setopt_array(
    $curl,
    [
        CURLOPT_URL =>
            $url,

        CURLOPT_RETURNTRANSFER =>
            true,

        CURLOPT_TIMEOUT =>
            15,

        CURLOPT_FOLLOWLOCATION =>
            true,

        CURLOPT_SSL_VERIFYPEER =>
            true
    ]
);

$respuesta =
    curl_exec($curl);

$codigoHttp =
    curl_getinfo(
        $curl,
        CURLINFO_HTTP_CODE
    );

curl_close($curl);

if (
    $respuesta === false ||
    $codigoHttp === 404
) {
    http_response_code(404);

    echo json_encode([
        "success" => false,
        "message" => "No encontramos ese Pokémon"
    ]);

    exit;
}

if ($codigoHttp !== 200) {
    http_response_code(502);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible consultar PokéAPI"
    ]);

    exit;
}

$detalle =
    json_decode(
        $respuesta,
        true
    );

$tipos = [];

foreach (
    $detalle["types"]
    as $tipo
) {
    $tipos[] =
        $tipo["type"]["name"];
}

$imagen =
    $detalle["sprites"]["other"]
    ["official-artwork"]
    ["front_default"]
    ??
    $detalle["sprites"]
    ["front_default"];

$resultado =
    json_encode([
        "success" => true,

        "pokemon" => [
            "id" =>
                $detalle["id"],

            "nombre" =>
                ucfirst(
                    $detalle["name"]
                ),

            "imagen" =>
                $imagen,

            "tipos" =>
                $tipos
        ]
    ]);

file_put_contents(
    $cacheFile,
    $resultado
);

echo $resultado;