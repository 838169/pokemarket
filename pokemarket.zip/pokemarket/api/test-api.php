<?php

require_once "../config/database.php";

echo "Conexión con la base de datos exitosa";