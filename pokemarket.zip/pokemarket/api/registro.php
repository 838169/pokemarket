<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);

    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit;
}

$datos = json_decode(file_get_contents("php://input"), true);

$nombre = trim($datos["nombre"] ?? "");
$email = trim($datos["email"] ?? "");
$password = $datos["password"] ?? "";

if ($nombre === "" || $email === "" || $password === "") {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "Todos los campos son obligatorios"
    ]);
    exit;
}


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "El correo no es válido"
    ]);
    exit;
}


if (strlen($password) < 6) {
    http_response_code(400);

    echo json_encode([
        "success" => false,
        "message" => "La contraseña debe tener mínimo 6 caracteres"
    ]);
    exit;
}

try {


    $consulta = $conexion->prepare(
        "SELECT id FROM usuarios WHERE email = :email"
    );

    $consulta->execute([
        ":email" => $email
    ]);

    if ($consulta->fetch()) {
        http_response_code(409);

        echo json_encode([
            "success" => false,
            "message" => "Ya existe un usuario con este correo"
        ]);
        exit;
    }


    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    // Insertamos el usuario
    $consulta = $conexion->prepare(
        "INSERT INTO usuarios (nombre, email, password)
         VALUES (:nombre, :email, :password)"
    );

    $consulta->execute([
        ":nombre" => $nombre,
        ":email" => $email,
        ":password" => $passwordHash
    ]);

    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Usuario registrado correctamente"
    ]);

} catch (PDOException $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error interno del servidor"
    ]);
}