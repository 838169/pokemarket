<?php

declare(strict_types=1);

namespace TrainerService;

use PDO;
use PDOException;

final class ControladorAuth
{
    public function __construct(
        private readonly PDO $conexion,
        private readonly SessionManager $sesion
    ) {
    }

    public function register(): never
    {
        $datos = JsonResponse::body();
        $nombre = trim((string) ($datos['nombre'] ?? ''));
        $email = trim((string) ($datos['email'] ?? ''));
        $password = (string) ($datos['password'] ?? '');

        if ($nombre === '' || $email === '' || $password === '') {
            JsonResponse::error('Todos los campos son obligatorios', 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            JsonResponse::error('El correo no es válido', 400);
        }

        if (strlen($password) < 6) {
            JsonResponse::error('La contraseña debe tener mínimo 6 caracteres', 400);
        }

        try {
            $consulta = $this->conexion->prepare('SELECT id FROM usuarios WHERE email = :email');
            $consulta->execute([':email' => $email]);

            if ($consulta->fetch()) {
                JsonResponse::error('Ya existe un usuario con este correo', 409);
            }

            $consulta = $this->conexion->prepare(
                'INSERT INTO usuarios (nombre, email, password) VALUES (:nombre, :email, :password)'
            );
            $consulta->execute([
                ':nombre' => $nombre,
                ':email' => $email,
                ':password' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            JsonResponse::send([
                'success' => true,
                'message' => 'Usuario registrado correctamente',
            ], 201);
        } catch (PDOException) {
            JsonResponse::error('Error interno del servidor', 500);
        }
    }

    public function login(): never
    {
        $datos = JsonResponse::body();
        $email = trim((string) ($datos['email'] ?? ''));
        $password = (string) ($datos['password'] ?? '');

        if ($email === '' || $password === '') {
            JsonResponse::error('Correo y contraseña son obligatorios', 400);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            JsonResponse::error('El correo no es válido', 400);
        }

        try {
            $consulta = $this->conexion->prepare(
                'SELECT id, nombre, email, password FROM usuarios WHERE email = :email LIMIT 1'
            );
            $consulta->execute([':email' => $email]);
            $usuario = $consulta->fetch(PDO::FETCH_ASSOC);

            if (!$usuario || !password_verify($password, $usuario['password'])) {
                JsonResponse::error('Correo o contraseña incorrectos', 401);
            }

            $this->sesion->login($usuario);
            JsonResponse::send([
                'success' => true,
                'message' => 'Inicio de sesión correcto',
                'usuario' => [
                    'id' => (int) $usuario['id'],
                    'nombre' => $usuario['nombre'],
                ],
            ]);
        } catch (PDOException) {
            JsonResponse::error('Error interno del servidor', 500);
        }
    }

    public function logout(): never
    {
        $this->sesion->logout();
        JsonResponse::send([
            'success' => true,
            'message' => 'Sesión cerrada correctamente',
        ]);
    }

    public function me(): never
    {
        $usuario = $this->sesion->user();

        if ($usuario === null) {
            JsonResponse::error('Usuario no autenticado', 401);
        }

        JsonResponse::send([
            'success' => true,
            'usuario' => $usuario,
        ]);
    }
}
