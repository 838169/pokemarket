<?php

declare(strict_types=1);

namespace TrainerService;

use PDO;

final class ControladorBatalla
{
    private PDO $conexion;
    private SessionManager $sesion;
    private PokemonServiceClient $pokemonService;

    public function __construct()
    {
        $config = require dirname(__DIR__) . '/bootstrap.php';
        $this->conexion = require dirname(__DIR__) . '/config/database.php';
        $this->sesion = new SessionManager($config);
        $this->pokemonService = new PokemonServiceClient(
            $config['pokemon_service_url'],
            $config['pokemon_service_timeout']
        );
    }

    public function start(): never
    {
        $usuarioId = $this->usuarioId();
        $this->sesion->start();
        $actual = $_SESSION['batalla'] ?? null;

        if (is_array($actual) && ($actual['estado'] ?? null) === 'en_curso') {
            JsonResponse::error('Ya existe una batalla activa', 409);
        }

        $datos = JsonResponse::body();
        $equipoId = $this->positiveInteger($datos['equipo_id'] ?? null, 'equipo_id');
        $equipo = $this->team($equipoId, $usuarioId);
        $miembros = $this->members($equipoId);

        if ($miembros === []) {
            JsonResponse::error('El equipo debe tener al menos un Pokémon', 409);
        }

        $jugador = [];
        $jugadorIds = array_map(static fn (array $miembro): int => (int) $miembro['pokemon_id'], $miembros);
        $jugadorPorId = [];
        foreach (array_chunk($jugadorIds, 2) as $loteJugador) {
            $jugadorDetalles = $this->pokemonService->batch($loteJugador);

            if ($jugadorDetalles === null) {
                JsonResponse::error('No fue posible obtener los datos de combate del equipo del jugador', 502);
            }

            foreach ($jugadorDetalles as $pokemon) {
                if (is_array($pokemon) && isset($pokemon['id'])) {
                    $jugadorPorId[(int) $pokemon['id']] = $pokemon;
                }
            }
        }

        foreach ($jugadorIds as $pokemonId) {
            $pokemon = $jugadorPorId[$pokemonId] ?? null;

            if (
                !is_array($pokemon)
                || !is_array($pokemon['estadisticas'] ?? null)
                || !is_array($pokemon['tipos'] ?? null)
                || !is_array($pokemon['movimientos'] ?? null)
                || $pokemon['movimientos'] === []
            ) {
                JsonResponse::error("No fue posible cargar los datos de combate del Pokémon {$pokemonId}", 502);
            }

            $jugador[] = $this->combatPokemon($pokemon);
        }

        $rivalIds = $this->rivalIds(count($jugador), array_column($jugador, 'id'));
        $rival = [];
        $obtenidos = [];

        foreach (array_chunk($rivalIds, 2) as $candidatos) {
            $pendientes = array_values(array_filter(
                $candidatos,
                static fn (int $pokemonId): bool => !array_key_exists($pokemonId, $obtenidos)
            ));

            if ($pendientes !== []) {
                $detalles = $this->pokemonService->batch($pendientes);

                if (is_array($detalles)) {
                    foreach ($detalles as $pokemon) {
                        if (is_array($pokemon) && isset($pokemon['id'])) {
                            $obtenidos[(int) $pokemon['id']] = $pokemon;
                        }
                    }
                }
            }

            foreach ($candidatos as $pokemonId) {
                $pokemon = $obtenidos[$pokemonId] ?? null;
                if (!is_array($pokemon) || !is_array($pokemon['movimientos'] ?? null) || $pokemon['movimientos'] === []) {
                    continue;
                }

                $rival[] = $this->combatPokemon($pokemon);

                if (count($rival) >= count($jugador)) {
                    break 2;
                }
            }
        }

        if (count($rival) < count($jugador)) {
            JsonResponse::error('No fue posible generar el equipo rival', 502);
        }

        $id = bin2hex(random_bytes(8));
        $_SESSION['batalla'] = [
            'id' => $id,
            'estado' => 'en_curso',
            'equipo_jugador' => [
                'id' => $equipo['id'],
                'nombre' => $equipo['nombre'],
                'pokemon' => $jugador,
            ],
            'equipo_rival' => [
                'pokemon' => $rival,
            ],
            'activo_jugador' => 0,
            'activo_rival' => 0,
            'turno' => 1,
            'resultado' => null,
            'historial' => [],
        ];

        JsonResponse::send([
            'success' => true,
            'batalla' => $this->state($_SESSION['batalla']),
        ], 201);
    }

    public function current(string $battleId): never
    {
        $batalla = $this->battle($battleId);
        JsonResponse::send([
            'success' => true,
            'batalla' => $this->state($batalla),
        ]);
    }

    public function active(): never
    {
        $this->usuarioId();
        $this->sesion->start();
        $batalla = $_SESSION['batalla'] ?? null;
        JsonResponse::send([
            'success' => true,
            'batalla' => is_array($batalla) && ($batalla['estado'] ?? null) === 'en_curso'
                ? $this->state($batalla)
                : null,
        ]);
    }

    public function turn(string $battleId): never
    {
        $this->sesion->start();
        $batalla = $this->battle($battleId);

        if ($batalla['estado'] !== 'en_curso') {
            JsonResponse::error('La batalla ya finalizó', 409);
        }

        $jugador = &$batalla['equipo_jugador']['pokemon'];
        $rival = &$batalla['equipo_rival']['pokemon'];
        $activoJugador = (int) $batalla['activo_jugador'];
        $activoRival = (int) $batalla['activo_rival'];
        $movimiento = (string) (JsonResponse::body()['movimiento'] ?? '');
        $movimientoJugador = $this->findMove($jugador[$activoJugador], $movimiento);

        if ($movimientoJugador === null) {
            JsonResponse::error('El movimiento no está disponible para el Pokémon activo', 400);
        }

        $movimientosRival = $rival[$activoRival]['movimientos'] ?? [];
        if ($movimientosRival === []) {
            JsonResponse::error('El Pokémon rival no tiene movimientos disponibles', 502);
        }
        $movimientoRival = $movimientosRival[array_rand($movimientosRival)];
        $jugadorPrimero = $jugador[$activoJugador]['estadisticas']['velocidad'] >= $rival[$activoRival]['estadisticas']['velocidad'];
        $orden = $jugadorPrimero
            ? [['lado' => 'jugador', 'movimiento' => $movimientoJugador], ['lado' => 'rival', 'movimiento' => $movimientoRival]]
            : [['lado' => 'rival', 'movimiento' => $movimientoRival], ['lado' => 'jugador', 'movimiento' => $movimientoJugador]];
        $acciones = [];

        foreach ($orden as $ataque) {
            if ($batalla['estado'] !== 'en_curso') {
                break;
            }

            $acciones[] = $this->attack($batalla, $ataque['lado'], $ataque['movimiento']);
            $this->appendFaintAndEntry($batalla, $acciones, $ataque['lado'] === 'jugador' ? 'rival' : 'jugador');
        }

        if ($batalla['estado'] === 'en_curso') {
            $batalla['turno']++;
        }

        $_SESSION['batalla'] = $batalla;
        JsonResponse::send([
            'success' => true,
            'acciones' => $acciones,
            'estado_final' => $this->state($batalla),
            'historial' => $batalla['historial'],
        ]);
    }

    public function switchPokemon(string $battleId): never
    {
        $this->sesion->start();
        $batalla = $this->battle($battleId);

        if ($batalla['estado'] !== 'en_curso') {
            JsonResponse::error('La batalla ya finalizó', 409);
        }

        $pokemonId = $this->positiveInteger(JsonResponse::body()['pokemon_id'] ?? null, 'pokemon_id');
        $pokemon = &$batalla['equipo_jugador']['pokemon'];
        $actual = (int) $batalla['activo_jugador'];
        $siguiente = null;

        foreach ($pokemon as $indice => $item) {
            if ((int) $item['id'] === $pokemonId) {
                $siguiente = $indice;
                break;
            }
        }

        if ($siguiente === null) {
            JsonResponse::error('El Pokémon no pertenece a tu equipo', 400);
        }

        if ($siguiente === $actual) {
            JsonResponse::error('Ese Pokémon ya está activo', 400);
        }

        if ($pokemon[$siguiente]['derrotado'] || $pokemon[$siguiente]['hp_actual'] <= 0) {
            JsonResponse::error('No puedes cambiar a un Pokémon debilitado', 400);
        }

        $acciones = [[
            'tipo' => 'salida',
            'lado' => 'jugador',
            'pokemon_id' => $pokemon[$actual]['id'],
            'pokemon_nombre' => $pokemon[$actual]['nombre'],
            'mensaje' => $pokemon[$actual]['nombre'] . ' vuelve a su Poké Ball.',
        ]];
        $batalla['activo_jugador'] = $siguiente;
        $nuevo = $pokemon[$siguiente];
        $acciones[] = $this->entryAction('jugador', $nuevo);
        $this->addHistory($batalla, $nuevo['nombre'] . ' entró al combate.');

        $rival = &$batalla['equipo_rival']['pokemon'];
        $activoRival = (int) $batalla['activo_rival'];
        $movimientosRival = $rival[$activoRival]['movimientos'] ?? [];
        if ($movimientosRival === []) {
            JsonResponse::error('El Pokémon rival no tiene movimientos disponibles', 502);
        }
        $acciones[] = $this->attack($batalla, 'rival', $movimientosRival[array_rand($movimientosRival)]);
        $this->appendFaintAndEntry($batalla, $acciones, 'jugador');

        if ($batalla['estado'] === 'en_curso') {
            $batalla['turno']++;
        }

        $_SESSION['batalla'] = $batalla;
        JsonResponse::send([
            'success' => true,
            'acciones' => $acciones,
            'estado_final' => $this->state($batalla),
            'historial' => $batalla['historial'],
        ]);
    }

    public function abandon(string $battleId): never
    {
        $this->sesion->start();
        $batalla = $this->battle($battleId);
        $batalla['estado'] = 'abandonada';
        $batalla['resultado'] = 'abandono';
        $_SESSION['batalla'] = $batalla;
        JsonResponse::send([
            'success' => true,
            'batalla' => $this->state($batalla),
        ]);
    }

    private function attack(array &$batalla, string $lado, array $movimiento): array
    {
        if ($lado === 'jugador') {
            $atacante =& $batalla['equipo_jugador']['pokemon'][$batalla['activo_jugador']];
        } else {
            $atacante =& $batalla['equipo_rival']['pokemon'][$batalla['activo_rival']];
        }
        $defensorLado = $lado === 'jugador' ? 'rival' : 'jugador';
        if ($defensorLado === 'jugador') {
            $defensor =& $batalla['equipo_jugador']['pokemon'][$batalla['activo_jugador']];
        } else {
            $defensor =& $batalla['equipo_rival']['pokemon'][$batalla['activo_rival']];
        }
        $efectividad = $this->effectiveness($movimiento['tipo'], $defensor['tipos']);
        $hpAnterior = $defensor['hp_actual'];
        $danio = $this->damage($atacante, $defensor, $movimiento, $efectividad);
        $defensor['hp_actual'] = max(0, $defensor['hp_actual'] - $danio);
        $debilitado = $defensor['hp_actual'] === 0;
        $mensaje = $efectividad === 2 ? '¡Es súper efectivo!' : ($efectividad === 0.5 ? 'No es muy efectivo...' : ($efectividad === 0 ? 'No afecta al objetivo.' : null));
        $this->addHistory($batalla, $atacante['nombre'] . ' usó ' . ($movimiento['nombre_mostrado'] ?? $movimiento['nombre']) . '.');
        $this->addHistory($batalla, $danio . ' puntos de daño.');

        return [
            'tipo' => 'ataque',
            'actor' => $lado,
            'pokemon_id' => $atacante['id'],
            'pokemon_nombre' => $atacante['nombre'],
            'movimiento' => $movimiento,
            'objetivo_id' => $defensor['id'],
            'danio' => $danio,
            'hp_anterior' => $hpAnterior,
            'hp_nuevo' => $defensor['hp_actual'],
            'hp_maximo' => $defensor['hp_maximo'],
            'efectividad' => $efectividad,
            'mensaje' => $mensaje,
            'debilitado' => $debilitado,
        ];
    }

    private function appendFaintAndEntry(array &$batalla, array &$acciones, string $lado): void
    {
        if ($lado === 'jugador') {
            $equipo =& $batalla['equipo_jugador']['pokemon'];
        } else {
            $equipo =& $batalla['equipo_rival']['pokemon'];
        }
        $indice = $lado === 'jugador' ? (int) $batalla['activo_jugador'] : (int) $batalla['activo_rival'];

        if ($equipo[$indice]['hp_actual'] > 0) {
            return;
        }

        $equipo[$indice]['derrotado'] = true;
        $this->addHistory($batalla, $equipo[$indice]['nombre'] . ' quedó debilitado.');
        $acciones[] = [
            'tipo' => 'debilitamiento',
            'lado' => $lado,
            'pokemon_id' => $equipo[$indice]['id'],
            'mensaje' => $equipo[$indice]['nombre'] . ' quedó debilitado.',
        ];

        $siguiente = $this->nextIndex($equipo, $indice);

        if ($siguiente === null) {
            $batalla['estado'] = 'finalizada';
            $batalla['resultado'] = $lado === 'jugador' ? 'derrota' : 'victoria';
            return;
        }

        if ($lado === 'jugador') {
            $batalla['activo_jugador'] = $siguiente;
        } else {
            $batalla['activo_rival'] = $siguiente;
        }

        $nuevo = $equipo[$siguiente];
        $acciones[] = $this->entryAction($lado, $nuevo);
        $this->addHistory($batalla, $nuevo['nombre'] . ' entró al combate.');
    }

    private function damage(array $atacante, array $defensor, array $movimiento, float $efectividad): int
    {
        if ($efectividad === 0.0) {
            return 0;
        }

        $ataque = max(1, (int) $atacante['estadisticas']['ataque']);
        $defensa = max(1, (int) $defensor['estadisticas']['defensa']);
        $base = floor((((2 * 50 / 5 + 2) * (int) $movimiento['potencia'] * $ataque / $defensa) / 50) + 2);
        $stab = in_array($movimiento['tipo'], $atacante['tipos'], true) ? 1.5 : 1.0;

        return max(1, (int) floor($base * $stab * $efectividad * (random_int(85, 100) / 100)));
    }

    private function effectiveness(string $moveType, array $defenderTypes): float
    {
        $strong = [
            'normal' => [], 'fire' => ['grass', 'ice', 'bug', 'steel'], 'water' => ['fire', 'ground', 'rock'],
            'electric' => ['water', 'flying'], 'grass' => ['water', 'ground', 'rock'], 'ice' => ['grass', 'ground', 'flying', 'dragon'],
            'fighting' => ['normal', 'ice', 'rock', 'dark', 'steel'], 'poison' => ['grass', 'fairy'], 'ground' => ['fire', 'electric', 'poison', 'rock', 'steel'],
            'flying' => ['grass', 'fighting', 'bug'], 'psychic' => ['fighting', 'poison'], 'bug' => ['grass', 'psychic', 'dark'],
            'rock' => ['fire', 'ice', 'flying', 'bug'], 'ghost' => ['psychic', 'ghost'], 'dragon' => ['dragon'],
            'dark' => ['psychic', 'ghost'], 'steel' => ['ice', 'rock', 'fairy'], 'fairy' => ['fighting', 'dragon', 'dark'],
        ];
        $weak = [
            'normal' => ['rock', 'steel'], 'fire' => ['fire', 'water', 'rock', 'dragon'], 'water' => ['water', 'grass', 'dragon'],
            'electric' => ['electric', 'grass', 'dragon'], 'grass' => ['fire', 'grass', 'poison', 'flying', 'bug', 'dragon', 'steel'],
            'ice' => ['fire', 'water', 'ice', 'steel'], 'fighting' => ['poison', 'flying', 'psychic', 'bug', 'fairy'],
            'poison' => ['poison', 'ground', 'rock', 'ghost'], 'ground' => ['grass', 'bug'], 'flying' => ['electric', 'rock', 'steel'],
            'psychic' => ['psychic', 'steel'], 'bug' => ['fire', 'fighting', 'poison', 'flying', 'ghost', 'steel', 'fairy'],
            'rock' => ['fighting', 'ground', 'steel'], 'ghost' => ['dark'], 'dragon' => ['steel'],
            'dark' => ['fighting', 'dark', 'fairy'], 'steel' => ['fire', 'water', 'electric', 'steel'], 'fairy' => ['fire', 'poison', 'steel'],
        ];
        $immune = ['normal' => ['ghost'], 'fighting' => ['ghost'], 'poison' => ['steel'], 'ground' => ['flying'], 'electric' => ['ground'], 'psychic' => ['dark'], 'ghost' => ['normal'], 'dragon' => ['fairy']];
        $multiplier = 1.0;

        foreach ($defenderTypes as $type) {
            if (in_array($type, $immune[$moveType] ?? [], true)) {
                return 0.0;
            }
            if (in_array($type, $strong[$moveType] ?? [], true)) {
                $multiplier *= 2;
            } elseif (in_array($type, $weak[$moveType] ?? [], true)) {
                $multiplier *= 0.5;
            }
        }

        return $multiplier;
    }

    private function combatPokemon(array $pokemon): array
    {
        $stats = $pokemon['estadisticas'] ?? [];
        $movimientos = array_map(
            fn (array $movimiento): array => $this->movement($movimiento),
            array_slice($pokemon['movimientos'] ?? $pokemon['movimientos_disponibles'] ?? [], 0, 4)
        );
        $hp = (int) ($stats['hp'] ?? 0) + 50;

        return [
            'id' => (int) $pokemon['id'],
            'nombre' => $pokemon['nombre'],
            'tipos' => $pokemon['tipos'],
            'estadisticas' => $stats,
            'movimientos' => $movimientos,
            'movimientos_disponibles' => $movimientos,
            'sprite_animado' => $pokemon['sprite_animado'] ?? null,
            'imagen_fallback' => $pokemon['imagen_fallback'] ?? null,
            'hp_actual' => $hp,
            'hp_maximo' => $hp,
            'derrotado' => false,
        ];
    }

    private function state(array $batalla): array
    {
        return $batalla;
    }

    private function battle(string $id): array
    {
        $this->sesion->start();
        $batalla = $_SESSION['batalla'] ?? null;

        if (!is_array($batalla) || !hash_equals((string) ($batalla['id'] ?? ''), $id)) {
            JsonResponse::error('Batalla no encontrada', 404);
        }

        return $batalla;
    }

    private function usuarioId(): int
    {
        $usuario = $this->sesion->user();
        if ($usuario === null) {
            JsonResponse::error('Usuario no autenticado', 401);
        }
        return $usuario['id'];
    }

    private function team(int $id, int $usuarioId): array
    {
        $consulta = $this->conexion->prepare('SELECT id, nombre FROM equipos WHERE id = :id AND usuario_id = :usuario_id');
        $consulta->execute([':id' => $id, ':usuario_id' => $usuarioId]);
        $equipo = $consulta->fetch(PDO::FETCH_ASSOC);
        if (!$equipo) {
            JsonResponse::error('Equipo no encontrado', 404);
        }
        return $equipo;
    }

    private function members(int $teamId): array
    {
        $consulta = $this->conexion->prepare('SELECT posicion, pokemon_id FROM miembros_equipo WHERE equipo_id = :equipo_id ORDER BY posicion');
        $consulta->execute([':equipo_id' => $teamId]);
        return $consulta->fetchAll(PDO::FETCH_ASSOC);
    }

    private function rivalIds(int $count, array $playerIds): array
    {
        $poolControlado = [
            3, 6, 9, 26, 31, 34, 59, 65, 68, 76, 94, 123,
            125, 126, 127, 128, 130, 131, 134, 135, 136, 142, 143, 149,
        ];
        $pool = array_values(array_diff($poolControlado, $playerIds));
        shuffle($pool);
        return $pool;
    }

    private function findMove(array $pokemon, string $name): ?array
    {
        $target = $this->moveName($name);
        foreach ($pokemon['movimientos'] as $move) {
            if ($this->moveName((string) $move['nombre']) === $target) {
                return $move;
            }
        }
        return null;
    }

    private function movement(array $movement): array
    {
        $name = strtolower(str_replace(' ', '-', trim((string) ($movement['nombre'] ?? ''))));
        $translations = [
            'thunder-punch' => 'Puño Trueno', 'thunder-shock' => 'Impactrueno', 'thunderbolt' => 'Rayo',
            'thunder' => 'Trueno', 'fire-punch' => 'Puño Fuego', 'water-gun' => 'Pistola Agua',
            'vine-whip' => 'Látigo Cepa', 'razor-leaf' => 'Hoja Afilada', 'solar-beam' => 'Rayo Solar',
            'mega-punch' => 'Megapuño', 'scratch' => 'Arañazo', 'tackle' => 'Placaje',
            'ember' => 'Ascuas', 'flamethrower' => 'Lanzallamas', 'fly' => 'Vuelo',
            'wing-attack' => 'Ataque Ala', 'headbutt' => 'Golpe Cabeza', 'cut' => 'Corte',
            'bind' => 'Atadura', 'mega-drain' => 'Megaagotar', 'pay-day' => 'Día de Pago',
            'slam' => 'Atizar',
        ];
        $movement['nombre'] = $name;
        $movement['nombre_mostrado'] = $translations[$name] ?? ucfirst(str_replace('-', ' ', $name));
        return $movement;
    }

    private function entryAction(string $lado, array $pokemon): array
    {
        return [
            'tipo' => 'entrada',
            'lado' => $lado,
            'pokemon_id' => $pokemon['id'],
            'pokemon_nombre' => $pokemon['nombre'],
            'hp_actual' => $pokemon['hp_actual'],
            'hp_maximo' => $pokemon['hp_maximo'],
            'sprite_animado' => $pokemon['sprite_animado'],
            'imagen_fallback' => $pokemon['imagen_fallback'],
        ];
    }

    private function moveName(string $name): string
    {
        return strtolower(str_replace(' ', '-', trim($name)));
    }

    private function nextIndex(array $pokemon, int $current): ?int
    {
        for ($index = $current + 1, $total = count($pokemon); $index < $total; $index++) {
            if ($pokemon[$index]['hp_actual'] > 0) {
                return $index;
            }
        }
        return null;
    }

    private function addHistory(array &$batalla, string $texto): void
    {
        $batalla['historial'][] = $texto;
        $batalla['historial'] = array_slice($batalla['historial'], -50);
    }

    private function positiveInteger(mixed $value, string $name): int
    {
        if (!is_scalar($value) || !preg_match('/^[1-9][0-9]*$/', (string) $value)) {
            JsonResponse::error("{$name} debe ser un entero positivo", 400);
        }
        return (int) $value;
    }
}
