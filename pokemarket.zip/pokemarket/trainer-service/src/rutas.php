<?php

declare(strict_types=1);

use TrainerService\ControladorAuth;
use TrainerService\ControladorColeccion;
use TrainerService\ControladorEquipos;
use TrainerService\ControladorBatalla;
use TrainerService\JsonResponse;

return static function (
    ControladorAuth $auth,
    ControladorColeccion $coleccion,
    ControladorEquipos $equipos,
    ?ControladorBatalla $batallas = null
): never {
    $batallas ??= new ControladorBatalla();
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        JsonResponse::options();
    }

    $method = $_SERVER['REQUEST_METHOD'];
    $path = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '', '/');

    if ($method === 'POST' && $path === '/trainer-api/v1/auth/register') {
        $auth->register();
    }

    if ($method === 'POST' && $path === '/trainer-api/v1/auth/login') {
        $auth->login();
    }

    if ($method === 'POST' && $path === '/trainer-api/v1/auth/logout') {
        $auth->logout();
    }

    if ($method === 'GET' && $path === '/trainer-api/v1/auth/me') {
        $auth->me();
    }

    if ($method === 'GET' && $path === '/trainer-api/v1/collection') {
        $coleccion->list();
    }

    if ($method === 'POST' && $path === '/trainer-api/v1/collection') {
        $coleccion->add();
    }

    if ($method === 'DELETE' && preg_match('#^/trainer-api/v1/collection/([^/]+)$#', $path, $matches)) {
        $coleccion->delete($matches[1]);
    }

    if ($method === 'POST' && $path === '/trainer-api/v1/battles') {
        $batallas->start();
    }

    if ($method === 'GET' && $path === '/trainer-api/v1/battles/current') {
        $batallas->active();
    }

    if ($method === 'POST' && preg_match('#^/trainer-api/v1/battles/([^/]+)/switch$#', $path, $matches)) {
        $batallas->switchPokemon($matches[1]);
    }

    if ($method === 'POST' && preg_match('#^/trainer-api/v1/battles/([^/]+)/turn$#', $path, $matches)) {
        $batallas->turn($matches[1]);
    }

    if ($method === 'GET' && preg_match('#^/trainer-api/v1/battles/([^/]+)$#', $path, $matches)) {
        $batallas->current($matches[1]);
    }

    if ($method === 'DELETE' && preg_match('#^/trainer-api/v1/battles/([^/]+)$#', $path, $matches)) {
        $batallas->abandon($matches[1]);
    }

    if ($method === 'GET' && $path === '/trainer-api/v1/teams') {
        $equipos->list();
    }

    if ($method === 'POST' && $path === '/trainer-api/v1/teams') {
        $equipos->create();
    }

    if ($method === 'PUT' && preg_match('#^/trainer-api/v1/teams/([^/]+)/slots/([^/]+)$#', $path, $matches)) {
        $equipos->saveMember($matches[1], $matches[2]);
    }

    if ($method === 'DELETE' && preg_match('#^/trainer-api/v1/teams/([^/]+)/slots/([^/]+)$#', $path, $matches)) {
        $equipos->deleteMember($matches[1], $matches[2]);
    }

    if ($method === 'GET' && preg_match('#^/trainer-api/v1/teams/([^/]+)$#', $path, $matches)) {
        $equipos->detail($matches[1]);
    }

    if ($method === 'PATCH' && preg_match('#^/trainer-api/v1/teams/([^/]+)$#', $path, $matches)) {
        $equipos->update($matches[1]);
    }

    if ($method === 'DELETE' && preg_match('#^/trainer-api/v1/teams/([^/]+)$#', $path, $matches)) {
        $equipos->delete($matches[1]);
    }

    JsonResponse::error('Ruta no encontrada o método no permitido', 404);
};
