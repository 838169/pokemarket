<?php

declare(strict_types=1);

namespace TrainerService;

use PDO;
use PDOException;

final class ControladorColeccion
{
    public function __construct(
        private readonly PDO $conexion,
        private readonly SessionManager $sesion,
        private readonly PokemonServiceClient $pokemonService
    ) {
    }

    public function list(): never
    {
        $usuarioId = $this->usuarioId();

        try {
            $consulta = $this->conexion->prepare(
                'SELECT pokemon_id, fecha_agregado FROM coleccion WHERE usuario_id = :usuario_id ORDER BY fecha_agregado DESC'
            );
            $consulta->execute([':usuario_id' => $usuarioId]);
            $coleccion = $consulta->fetchAll(PDO::FETCH_ASSOC);
            JsonResponse::send([
                'success' => true,
                'total' => count($coleccion),
                'coleccion' => $coleccion,
            ]);
        } catch (PDOException) {
            JsonResponse::error('No fue posible consultar la colección', 500);
        }
    }

    public function add(): never
    {
        $usuarioId = $this->usuarioId();
        $datos = JsonResponse::body();
        $pokemonId = $this->pokemonId($datos['pokemon_id'] ?? null);
        $exists = $this->pokemonService->exists($pokemonId);

        if ($exists === null) {
            JsonResponse::error('No fue posible validar el Pokémon con pokemon-service', 502);
        }

        if ($exists === false) {
            JsonResponse::error('Pokémon no encontrado', 404);
        }

        try {
            $consulta = $this->conexion->prepare(
                'SELECT id FROM coleccion WHERE usuario_id = :usuario_id AND pokemon_id = :pokemon_id'
            );
            $consulta->execute([
                ':usuario_id' => $usuarioId,
                ':pokemon_id' => $pokemonId,
            ]);

            if ($consulta->fetch()) {
                JsonResponse::error('Este Pokémon ya está en tu colección', 409, ['already_exists' => true]);
            }

            $consulta = $this->conexion->prepare(
                'INSERT INTO coleccion (usuario_id, pokemon_id) VALUES (:usuario_id, :pokemon_id)'
            );
            $consulta->execute([
                ':usuario_id' => $usuarioId,
                ':pokemon_id' => $pokemonId,
            ]);
            JsonResponse::send([
                'success' => true,
                'message' => 'Pokémon agregado a tu colección',
            ], 201);
        } catch (PDOException) {
            JsonResponse::error('No fue posible guardar el Pokémon', 500);
        }
    }

    public function delete(string $pokemonId): never
    {
        $usuarioId = $this->usuarioId();
        $pokemonId = $this->pokemonId($pokemonId);

        try {
            $consulta = $this->conexion->prepare(
                'DELETE FROM coleccion WHERE usuario_id = :usuario_id AND pokemon_id = :pokemon_id'
            );
            $consulta->execute([
                ':usuario_id' => $usuarioId,
                ':pokemon_id' => $pokemonId,
            ]);

            if ($consulta->rowCount() === 0) {
                JsonResponse::error('El Pokémon no estaba en tu colección', 404);
            }

            JsonResponse::send([
                'success' => true,
                'message' => 'Pokémon eliminado de tu colección',
            ]);
        } catch (PDOException) {
            JsonResponse::error('No fue posible eliminar el Pokémon', 500);
        }
    }

    private function usuarioId(): int
    {
        $usuario = $this->sesion->user();

        if ($usuario === null) {
            JsonResponse::error('Usuario no autenticado', 401);
        }

        return $usuario['id'];
    }

    private function pokemonId(mixed $value): int
    {
        if (!is_scalar($value) || !preg_match('/^[1-9][0-9]*$/', (string) $value)) {
            JsonResponse::error('pokemon_id debe ser un entero positivo', 400);
        }

        return (int) $value;
    }
}
