<?php

declare(strict_types=1);

namespace TrainerService;

final class SessionManager
{
    public function __construct(private readonly array $config)
    {
    }

    public function start(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        session_name($this->config['session_name']);
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => $this->config['session_path'],
            'secure' => $this->config['session_secure'],
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    public function login(array $usuario): void
    {
        $this->start();
        session_regenerate_id(true);
        $_SESSION['usuario_id'] = (int) $usuario['id'];
        $_SESSION['usuario_nombre'] = $usuario['nombre'];
        $_SESSION['usuario_email'] = $usuario['email'];
    }

    public function user(): ?array
    {
        $this->start();

        if (!isset($_SESSION['usuario_id'])) {
            return null;
        }

        return [
            'id' => (int) $_SESSION['usuario_id'],
            'nombre' => $_SESSION['usuario_nombre'],
            'email' => $_SESSION['usuario_email'],
        ];
    }

    public function logout(): void
    {
        $this->start();
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            setcookie(session_name(), '', [
                'expires' => time() - 42000,
                'path' => $this->config['session_path'],
                'secure' => $this->config['session_secure'],
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }

        session_destroy();
    }
}
