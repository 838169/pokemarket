<?php

declare(strict_types=1);

namespace TrainerService;

final class PokemonServiceClient
{
    public function __construct(
        private readonly string $baseUrl,
        private readonly int $timeout
    ) {
    }

    public function exists(int $pokemonId): ?bool
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => $this->baseUrl . '/pokemon-api/v1/pokemon/' . $pokemonId,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);

        $body = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($body === false || $status >= 500 || $status === 0) {
            return null;
        }

        return $status === 200;
    }

    public function get(int $pokemonId): ?array
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => $this->baseUrl . '/pokemon-api/v1/pokemon/' . $pokemonId,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);

        $body = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($body === false || $status !== 200) {
            return null;
        }

        $data = json_decode($body, true);

        return is_array($data['pokemon'] ?? null) ? $data['pokemon'] : null;
    }

    public function batch(array $pokemonIds): ?array
    {
        $ids = array_values(array_unique(array_map('intval', $pokemonIds)));

        if ($ids === []) {
            return [];
        }

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $this->baseUrl . '/pokemon-api/v1/pokemon/batch?ids=' . implode(',', $ids),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);
        $body = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);

        if ($body === false || $status !== 200) {
            return null;
        }

        $data = json_decode($body, true);
        return is_array($data['pokemon'] ?? null) ? $data['pokemon'] : null;
    }
}
