# trainer-service

Servicio PHP para autenticación, colección y equipos. Las migraciones en `database/migrations` se ejecutan manualmente cuando se aprueben.

## Ejecutar

```powershell
C:\xampp\php\php.exe -S localhost:8002 -t public public/router.php
```

`pokemon-service` debe estar disponible en `http://localhost:8001` para agregar Pokémon a colección o equipos.
