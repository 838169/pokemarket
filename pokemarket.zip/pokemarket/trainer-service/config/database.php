<?php

declare(strict_types=1);

$host = 'localhost';
$dbname = 'pokemarket';
$username = 'root';
$password = '';

try {
    return new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $exception) {
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'success' => false,
        'message' => 'No fue posible conectar con la base de datos',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
