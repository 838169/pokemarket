<?php

declare(strict_types=1);

return [
    'pokemon_service_url' => 'http://localhost:8001',
    'pokemon_service_timeout' => 10,
    'allowed_origins' => [
        'http://localhost',
    ],
    'session_name' => 'TRAINERSESSID',
    'session_path' => '/trainer-api/',
    'session_secure' => false,
];
