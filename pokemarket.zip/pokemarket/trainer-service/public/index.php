<?php

declare(strict_types=1);

use TrainerService\ControladorAuth;
use TrainerService\ControladorColeccion;
use TrainerService\ControladorEquipos;
use TrainerService\JsonResponse;
use TrainerService\PokemonServiceClient;
use TrainerService\SessionManager;

$config = require dirname(__DIR__) . '/bootstrap.php';
JsonResponse::configure($config['allowed_origins']);
$conexion = require dirname(__DIR__) . '/config/database.php';
$sesion = new SessionManager($config);
$pokemonService = new PokemonServiceClient(
    $config['pokemon_service_url'],
    $config['pokemon_service_timeout']
);

$rutas = require dirname(__DIR__) . '/src/rutas.php';
$rutas(
    new ControladorAuth($conexion, $sesion),
    new ControladorColeccion($conexion, $sesion, $pokemonService),
    new ControladorEquipos($conexion, $sesion, $pokemonService)
);
