const listaEquipos = document.getElementById("listaEquipos");
const detalleEquipo = document.getElementById("detalleEquipo");
const formulario = document.getElementById("formEquipo");
const nombreEquipo = document.getElementById("nombreEquipo");
const mensaje = document.getElementById("mensajeEquipos");
const memoriaPokemon = new Map();
let equipos = [];
let coleccion = [];
let equipoActual = null;
let cargandoEquipo = 0;

function mostrarMensaje(texto = "", error = false) {
    mensaje.textContent = texto;
    mensaje.classList.toggle("error", error);
}

function renderizarLista() {
    if (equipos.length === 0) {
        listaEquipos.innerHTML = '<div class="loading">Aún no has creado equipos.</div>';
        return;
    }
    listaEquipos.replaceChildren();
    equipos.forEach(equipo => {
        const boton = document.createElement("button");
        boton.type = "button";
        boton.className = "equipo-item";
        boton.classList.toggle("activo", Number(equipoActual?.id) === Number(equipo.id));
        boton.innerHTML = `<strong>${PokeMarket.escaparHTML(equipo.nombre)}</strong>
            <span>${Number(equipo.total_miembros)} / 6</span>`;
        boton.addEventListener("click", () => cargarEquipo(equipo.id));
        listaEquipos.appendChild(boton);
    });
}

async function cargarDatos() {
    try {
        await PokeMarket.iniciarSesion();
        const [respuestaEquipos, respuestaColeccion] = await Promise.all([
            PokeMarket.trainer("/teams"),
            PokeMarket.trainer("/collection")
        ]);
        equipos = respuestaEquipos.equipos;
        coleccion = respuestaColeccion.coleccion;
        await PokeMarket.obtenerPokemonLote(coleccion.map(item => item.pokemon_id), memoriaPokemon);
        renderizarLista();
        if (equipos.length > 0) await cargarEquipo(equipos[0].id);
    } catch (error) {
        mostrarMensaje(error.message, true);
        listaEquipos.innerHTML = '<div class="loading">No fue posible cargar los equipos.</div>';
    }
}

async function cargarEquipo(id) {
    const solicitud = ++cargandoEquipo;
    detalleEquipo.innerHTML = '<div class="loading">Cargando equipo...</div>';
    try {
        const resultado = await PokeMarket.trainer(`/teams/${id}`);
        if (solicitud !== cargandoEquipo) return;
        equipoActual = resultado.equipo;
        await PokeMarket.obtenerPokemonLote(
            equipoActual.miembros.map(miembro => miembro.pokemon_id), memoriaPokemon
        );
        if (solicitud !== cargandoEquipo) return;
        actualizarEquipoLista();
        renderizarLista();
        renderizarEquipo();
    } catch (error) {
        if (solicitud !== cargandoEquipo) return;
        detalleEquipo.innerHTML = `<div class="empty-equipo"><p>${PokeMarket.escaparHTML(error.message)}</p></div>`;
    }
}

function actualizarEquipoLista() {
    const indice = equipos.findIndex(equipo => Number(equipo.id) === Number(equipoActual.id));
    if (indice >= 0) equipos[indice].total_miembros = equipoActual.miembros.length;
}

function opcionesColeccion(posicion) {
    const usados = new Set(equipoActual.miembros
        .filter(miembro => Number(miembro.posicion) !== posicion)
        .map(miembro => Number(miembro.pokemon_id)));
    return coleccion
        .map(item => memoriaPokemon.get(Number(item.pokemon_id)))
        .filter(pokemon => pokemon && !usados.has(Number(pokemon.id)))
        .map(pokemon => `<option value="${Number(pokemon.id)}">${PokeMarket.escaparHTML(pokemon.nombre)}</option>`)
        .join("");
}

function renderizarEquipo() {
    const miembros = new Map(equipoActual.miembros.map(miembro => [Number(miembro.posicion), miembro]));
    detalleEquipo.replaceChildren();
    const cabecera = document.createElement("div");
    cabecera.className = "cabecera-equipo";
    cabecera.innerHTML = `<div><h2>${PokeMarket.escaparHTML(equipoActual.nombre)}</h2>
        <p>${equipoActual.miembros.length} de 6 posiciones ocupadas</p></div>`;
    const eliminar = document.createElement("button");
    eliminar.type = "button";
    eliminar.className = "btn-eliminar-equipo";
    eliminar.textContent = "Eliminar equipo";
    eliminar.addEventListener("click", () => eliminarEquipo(eliminar));
    cabecera.appendChild(eliminar);
    detalleEquipo.appendChild(cabecera);

    const slots = document.createElement("div");
    slots.className = "equipo-slots";
    for (let posicion = 1; posicion <= 6; posicion += 1) {
        const miembro = miembros.get(posicion);
        slots.appendChild(crearSlot(posicion, miembro));
    }
    detalleEquipo.appendChild(slots);
}

function crearSlot(posicion, miembro) {
    const slot = document.createElement("article");
    slot.className = "equipo-slot";
    slot.innerHTML = `<span class="slot-numero">Posición ${posicion}</span>`;
    const pokemon = miembro ? memoriaPokemon.get(Number(miembro.pokemon_id)) : null;
    const contenido = document.createElement("div");
    contenido.className = pokemon ? "slot-pokemon" : "slot-vacio";
    if (pokemon) {
        const imagen = document.createElement("img");
        imagen.loading = "lazy";
        PokeMarket.configurarImagen(imagen, pokemon);
        const verDetalle = document.createElement("button");
        verDetalle.type = "button";
        verDetalle.textContent = pokemon.nombre;
        verDetalle.addEventListener("click", () => PokeMarket.mostrarDetalle(pokemon));
        contenido.append(imagen, verDetalle);
    } else {
        contenido.textContent = "Espacio disponible";
    }
    slot.appendChild(contenido);

    const selector = document.createElement("select");
    selector.className = "slot-selector";
    selector.innerHTML = `<option value="">${pokemon ? "Cambiar Pokémon" : "Agregar Pokémon"}</option>${opcionesColeccion(posicion)}`;
    selector.disabled = coleccion.length === 0;
    selector.addEventListener("change", () => guardarMiembro(posicion, selector));
    slot.appendChild(selector);

    if (pokemon) {
        const quitar = document.createElement("button");
        quitar.type = "button";
        quitar.className = "btn-quitar-miembro";
        quitar.textContent = "Quitar";
        quitar.addEventListener("click", () => quitarMiembro(posicion, quitar));
        slot.appendChild(quitar);
    }
    return slot;
}

async function guardarMiembro(posicion, selector) {
    const pokemonId = Number(selector.value);
    if (!pokemonId || !equipoActual) return;
    selector.disabled = true;
    try {
        await PokeMarket.trainer(`/teams/${equipoActual.id}/slots/${posicion}`, {
            method: "PUT",
            body: { pokemon_id: pokemonId }
        });
        const existente = equipoActual.miembros.findIndex(miembro => Number(miembro.posicion) === posicion);
        const miembro = { posicion, pokemon_id: pokemonId };
        if (existente >= 0) equipoActual.miembros[existente] = miembro;
        else equipoActual.miembros.push(miembro);
        actualizarEquipoLista();
        renderizarLista();
        renderizarEquipo();
        mostrarMensaje("Pokémon agregado al equipo.");
    } catch (error) {
        selector.value = "";
        selector.disabled = false;
        mostrarMensaje(error.message, true);
    }
}

async function quitarMiembro(posicion, boton) {
    boton.disabled = true;
    try {
        await PokeMarket.trainer(`/teams/${equipoActual.id}/slots/${posicion}`, { method: "DELETE" });
        equipoActual.miembros = equipoActual.miembros.filter(miembro => Number(miembro.posicion) !== posicion);
        actualizarEquipoLista();
        renderizarLista();
        renderizarEquipo();
        mostrarMensaje("Pokémon eliminado del equipo.");
    } catch (error) {
        boton.disabled = false;
        mostrarMensaje(error.message, true);
    }
}

async function eliminarEquipo(boton) {
    if (!window.confirm(`¿Eliminar el equipo ${equipoActual.nombre}?`)) return;
    boton.disabled = true;
    try {
        await PokeMarket.trainer(`/teams/${equipoActual.id}`, { method: "DELETE" });
        equipos = equipos.filter(equipo => Number(equipo.id) !== Number(equipoActual.id));
        equipoActual = null;
        renderizarLista();
        detalleEquipo.innerHTML = '<div class="empty-equipo"><h2>Equipo eliminado</h2><p>Crea o selecciona otro equipo.</p></div>';
        mostrarMensaje("Equipo eliminado correctamente.");
    } catch (error) {
        boton.disabled = false;
        mostrarMensaje(error.message, true);
    }
}

formulario.addEventListener("submit", async event => {
    event.preventDefault();
    const boton = formulario.querySelector("button");
    if (boton.disabled) return;
    boton.disabled = true;
    mostrarMensaje();
    try {
        const resultado = await PokeMarket.trainer("/teams", {
            method: "POST",
            body: { nombre: nombreEquipo.value.trim() }
        });
        equipos.unshift({ ...resultado.equipo, total_miembros: 0 });
        nombreEquipo.value = "";
        renderizarLista();
        await cargarEquipo(resultado.equipo.id);
        mostrarMensaje("Equipo creado correctamente.");
    } catch (error) {
        mostrarMensaje(error.message, true);
    } finally {
        boton.disabled = false;
    }
});

cargarDatos();
