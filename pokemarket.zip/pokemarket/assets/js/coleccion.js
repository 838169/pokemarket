const grid = document.getElementById("collectionGrid");
const totalColeccion = document.getElementById("totalColeccion");
const memoriaPokemon = new Map();

async function cargarColeccion() {
    grid.innerHTML = '<div class="loading">Cargando tu colección...</div>';
    try {
        await PokeMarket.iniciarSesion();
        const resultado = await PokeMarket.trainer("/collection");
        totalColeccion.textContent = resultado.coleccion.length;
        if (resultado.coleccion.length === 0) {
            mostrarColeccionVacia();
            return;
        }
        const pokemon = await PokeMarket.obtenerPokemonLote(
            resultado.coleccion.map(item => item.pokemon_id), memoriaPokemon
        );
        grid.replaceChildren();
        resultado.coleccion.forEach(item => {
            const datos = pokemon.get(Number(item.pokemon_id));
            if (datos) grid.appendChild(crearCard(datos));
        });
    } catch (error) {
        grid.innerHTML = `<div class="loading">${PokeMarket.escaparHTML(error.message)}
            <button type="button" class="btn-card">Reintentar</button></div>`;
        grid.querySelector("button").addEventListener("click", cargarColeccion, { once: true });
    }
}

function crearCard(pokemon) {
    const card = document.createElement("article");
    card.className = "collection-card";
    card.style.setProperty("--pokemon-glow", PokeMarket.colorTipo(pokemon.tipos[0]));
    card.innerHTML = `
        <div class="collection-card-header">
            <strong>${PokeMarket.escaparHTML(pokemon.nombre)}</strong>
            <span>N.º ${String(pokemon.id).padStart(3, "0")}</span>
        </div>
        <div class="collection-image"><img loading="lazy" decoding="async" alt=""></div>
        <div class="pokemon-types">${pokemon.tipos.map(tipo =>
            `<span class="type-badge">${PokeMarket.escaparHTML(tipo)}</span>`).join("")}</div>
        <div class="collection-actions">
            <button class="btn-card btn-detail" type="button">Ver detalles</button>
            <button class="btn-remove" type="button">Eliminar</button>
        </div>`;
    PokeMarket.configurarImagen(card.querySelector("img"), pokemon);
    card.querySelector(".btn-detail").addEventListener("click", () => PokeMarket.mostrarDetalle(pokemon));
    const eliminar = card.querySelector(".btn-remove");
    eliminar.addEventListener("click", () => eliminarPokemon(pokemon, card, eliminar));
    return card;
}

async function eliminarPokemon(pokemon, card, boton) {
    if (!window.confirm(`¿Eliminar ${pokemon.nombre} de tu colección?`)) return;
    boton.disabled = true;
    try {
        await PokeMarket.trainer(`/collection/${pokemon.id}`, { method: "DELETE" });
        card.remove();
        totalColeccion.textContent = Math.max(0, Number(totalColeccion.textContent) - 1);
        if (Number(totalColeccion.textContent) === 0) mostrarColeccionVacia();
    } catch (error) {
        alert(error.message);
    } finally {
        boton.disabled = false;
    }
}

function mostrarColeccionVacia() {
    grid.innerHTML = `
        <div class="empty-collection">
            <h2>Tu colección está vacía</h2>
            <p>Explora el catálogo y agrega tus primeros Pokémon.</p>
            <a href="catalogo.php">Explorar catálogo</a>
        </div>`;
}

cargarColeccion();
