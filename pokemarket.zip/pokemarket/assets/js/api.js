window.PokeMarket = (() => {
    const urls = {
        pokemon: "http://localhost:8001/pokemon-api/v1",
        trainer: "http://localhost:8002/trainer-api/v1"
    };
    let sesionActual = null;
    let cerrandoSesion = false;

    async function solicitar(servicio, ruta, opciones = {}) {
        const { body, ...resto } = opciones;
        let respuesta;
        try {
            respuesta = await fetch(urls[servicio] + ruta, {
                ...resto,
                credentials: servicio === "trainer" ? "include" : "omit",
                headers: body === undefined ? {} : { "Content-Type": "application/json" },
                body: body === undefined ? undefined : JSON.stringify(body)
            });
        } catch (error) {
            if (error.name === "AbortError") throw error;
            throw new Error("No fue posible conectar con el servicio. Intenta nuevamente.");
        }

        if (respuesta.status === 401 && servicio === "trainer") {
            sesionActual = undefined;
            if (document.body.dataset.protegida === "true") {
                window.location.replace("login.php");
            }
        }

        let datos;
        try {
            datos = await respuesta.json();
        } catch {
            throw new Error("El servicio devolvió una respuesta inválida.");
        }
        if (!respuesta.ok || !datos.success) {
            const error = new Error(datos.message || "No fue posible completar la solicitud.");
            error.status = respuesta.status;
            error.data = datos;
            throw error;
        }
        return datos;
    }

    const pokemon = (ruta, opciones) => solicitar("pokemon", ruta, opciones);
    const trainer = (ruta, opciones) => solicitar("trainer", ruta, opciones);

    async function iniciarSesion() {
        if (sesionActual === null) {
            sesionActual = trainer("/auth/me").catch(error => {
                sesionActual = null;
                throw error;
            });
        }
        const { usuario } = await sesionActual;
        cargarUsuario(usuario);
        return usuario;
    }

    function cargarUsuario(usuario) {
        const nombre = document.getElementById("usuarioNombre");
        const avatar = document.getElementById("usuarioAvatar");
        if (nombre) nombre.textContent = usuario.nombre || "";
        if (avatar) avatar.textContent = Array.from(usuario.nombre || "")[0]?.toUpperCase() || "";
    }

    const salir = document.getElementById("cerrarSesion");
    salir?.addEventListener("click", async event => {
        event.preventDefault();
        if (cerrandoSesion) return;
        cerrandoSesion = true;
        try {
            await trainer("/auth/logout", { method: "POST" });
            sesionActual = null;
            window.location.replace("login.php");
        } catch (error) {
            alert(error.message);
        } finally {
            cerrandoSesion = false;
        }
    });

    async function obtenerPokemonLote(ids, memoria = new Map()) {
        const faltantes = [...new Set(ids.map(Number))].filter(id => !memoria.has(id));
        for (let i = 0; i < faltantes.length; i += 20) {
            const lote = faltantes.slice(i, i + 20);
            const resultado = await pokemon(`/pokemon/batch?ids=${lote.join(",")}`);
            resultado.pokemon.forEach(item => memoria.set(Number(item.id), item));
        }
        return memoria;
    }

    function configurarImagen(imagen, datos) {
        const fuentes = [...new Set([
            datos.sprite_animado, datos.imagen_oficial, datos.imagen_fallback
        ].filter(Boolean))];
        let indice = 0;
        let fuenteActiva = fuentes[0] || "";
        imagen.alt = datos.nombre;
        imagen.onerror = () => {
            if (imagen.currentSrc !== fuenteActiva && imagen.src !== fuenteActiva) return;
            indice += 1;
            if (indice < fuentes.length) {
                fuenteActiva = fuentes[indice];
                imagen.src = fuenteActiva;
            } else {
                imagen.onerror = null;
                imagen.removeAttribute("src");
            }
        };
        if (fuentes.length) imagen.src = fuenteActiva;
        else imagen.removeAttribute("src");
    }

    function escaparHTML(valor) {
        const elemento = document.createElement("span");
        elemento.textContent = String(valor ?? "");
        return elemento.innerHTML;
    }

    function colorTipo(tipo) {
        const colores = {
            fire: "rgba(239, 68, 68, .65)", water: "rgba(59, 130, 246, .65)",
            electric: "rgba(250, 204, 21, .65)", grass: "rgba(34, 197, 94, .60)",
            poison: "rgba(168, 85, 247, .60)", psychic: "rgba(236, 72, 153, .60)",
            ice: "rgba(34, 211, 238, .60)", dragon: "rgba(99, 102, 241, .60)",
            dark: "rgba(71, 85, 105, .60)", fairy: "rgba(244, 114, 182, .60)",
            normal: "rgba(148, 163, 184, .50)"
        };
        return colores[tipo] ?? "rgba(255,255,255,.10)";
    }

    const modal = document.getElementById("pokemonModal");
    function cerrarDetalle() {
        modal.classList.remove("open");
        document.body.style.overflow = "";
    }
    if (modal) {
        document.getElementById("cerrarModal").addEventListener("click", cerrarDetalle);
        modal.querySelector(".modal-backdrop").addEventListener("click", cerrarDetalle);
        document.addEventListener("keydown", event => {
            if (event.key === "Escape" && modal.classList.contains("open")) cerrarDetalle();
        });
    }

    function mostrarDetalle(datos) {
        configurarImagen(document.getElementById("detalleImagen"), datos);
        document.getElementById("detalleNumero").textContent = `N.º ${String(datos.id).padStart(3, "0")}`;
        document.getElementById("detalleNombre").textContent = datos.nombre;
        document.getElementById("detalleTipos").innerHTML = datos.tipos
            .map(tipo => `<span class="type-badge">${escaparHTML(tipo)}</span>`).join("");
        document.getElementById("detalleDescripcion").textContent = datos.descripcion || "Información no disponible.";
        document.getElementById("detalleAltura").textContent = `${datos.altura} m`;
        document.getElementById("detallePeso").textContent = `${datos.peso} kg`;
        document.getElementById("detalleHabilidades").innerHTML = datos.habilidades.map(habilidad => `
            <div class="ability-item">
                <strong>${escaparHTML(habilidad.nombre)}</strong>
                <span>${habilidad.oculta ? "Oculta" : "Principal"}</span>
            </div>`).join("");
        modal.classList.add("open");
        document.body.style.overflow = "hidden";
    }

    if (document.body.dataset.protegida === "true") {
        iniciarSesion().catch(() => {});
    }

    return { pokemon, trainer, iniciarSesion, obtenerPokemonLote, configurarImagen,
        escaparHTML, colorTipo, mostrarDetalle };
})();
