const panelInicio = document.getElementById("panelInicio");
const panelCombate = document.getElementById("panelCombate");
const tarjetasEquipos = document.getElementById("tarjetasEquipos");
const iniciarBatalla = document.getElementById("iniciarBatalla");
const batallaActiva = document.getElementById("batallaActiva");
const continuarBatalla = document.getElementById("continuarBatalla");
const abandonarDesdeInicio = document.getElementById("abandonarDesdeInicio");
const mensajeBatalla = document.getElementById("mensajeBatalla");
const mensajeAccion = document.getElementById("mensajeAccion");
const indicadorTurno = document.getElementById("indicadorTurno");
const numeroTurno = document.getElementById("numeroTurno");
const turnoTexto = document.getElementById("turnoTexto");
const ultimoMovimiento = document.getElementById("ultimoMovimiento");
const efectividadTexto = document.getElementById("efectividadTexto");
const ladoJugador = document.getElementById("ladoJugador");
const ladoRival = document.getElementById("ladoRival");
const miniaturasJugador = document.getElementById("miniaturasJugador");
const miniaturasRival = document.getElementById("miniaturasRival");
const movimientos = document.getElementById("movimientos");
const historialBatalla = document.getElementById("historialBatalla");
const resultadoBatalla = document.getElementById("resultadoBatalla");
const volverEquipos = document.getElementById("volverEquipos");
const abandonarBatalla = document.getElementById("abandonarBatalla");
let batalla = null;
let procesando = false;
let equipoSeleccionado = null;
const memoriaPokemonBatalla = new Map();

function esperar(tiempo) {
    return new Promise(resolve => setTimeout(resolve, tiempo));
}

function mostrarMensaje(texto, error = false) {
    mensajeBatalla.textContent = texto;
    mensajeBatalla.classList.toggle("error", error);
}

function nombreMovimiento(nombre) {
    return String(nombre || "").replace(/-/g, " ").replace(/^./, letra => letra.toUpperCase());
}

function pokemonActivo(estado, lado) {
    const indice = lado === "jugador" ? estado.activo_jugador : estado.activo_rival;
    const equipo = lado === "jugador" ? estado.equipo_jugador.pokemon : estado.equipo_rival.pokemon;
    return equipo[indice];
}

function tarjetaPokemon(pokemon, lado) {
    if (!pokemon) return "";
    const hp = Math.max(0, Number(pokemon.hp_actual));
    const maximo = Math.max(1, Number(pokemon.hp_maximo));
    const porcentaje = Math.max(0, Math.min(100, hp / maximo * 100));
    const tipos = (pokemon.tipos || []).map(tipo => `<span class="type-badge">${PokeMarket.escaparHTML(tipo)}</span>`).join("");
    const stats = pokemon.estadisticas || {};
    return `<div class="pokemon-campo" data-pokemon-id="${Number(pokemon.id)}">
        <img data-sprite alt="${PokeMarket.escaparHTML(pokemon.nombre)}">
        <div class="pokemon-datos">
            <span class="estado-activo">Activo</span>
            <h2>${PokeMarket.escaparHTML(pokemon.nombre)}</h2>
            <div class="tipos-campo">${tipos}</div>
            <div class="barra-hp"><span data-hp-fill style="width:${porcentaje}%"></span></div>
            <span class="hp-texto" data-hp-texto>${hp} / ${maximo} HP</span>
            <div class="stats-combate"><span>Vel. ${Number(stats.velocidad || 0)}</span><span>Ata. ${Number(stats.ataque || 0)}</span><span>Def. ${Number(stats.defensa || 0)}</span></div>
        </div>
    </div>`;
}

function renderizarLado(contenedor, estado, lado) {
    const activo = pokemonActivo(estado, lado);
    contenedor.innerHTML = tarjetaPokemon(activo, lado);
    const imagen = contenedor.querySelector("[data-sprite]");
    if (imagen) PokeMarket.configurarImagen(imagen, activo);
}

function renderizarMiniaturas(contenedor, pokemon, activo, lado) {
    contenedor.replaceChildren();
    pokemon.forEach((item, indice) => {
        const imagen = document.createElement("img");
        imagen.className = "miniatura";
        imagen.dataset.pokemonId = item.id;
        imagen.alt = item.nombre;
        imagen.title = item.nombre;
        imagen.classList.toggle("activo", indice === activo);
        imagen.classList.toggle("derrotado", item.derrotado || Number(item.hp_actual) <= 0);
        if (lado === "jugador" && indice !== activo && !item.derrotado && Number(item.hp_actual) > 0 && batalla?.estado === "en_curso" && !procesando) {
            imagen.classList.add("miniatura-seleccionable");
            imagen.addEventListener("click", () => cambiarPokemon(Number(item.id)));
        }
        PokeMarket.configurarImagen(imagen, item);
        contenedor.appendChild(imagen);
    });
}

function renderizarHistorial(historial) {
    historialBatalla.replaceChildren();
    (historial || []).slice(-6).forEach(texto => {
        const linea = document.createElement("p");
        linea.textContent = texto;
        historialBatalla.appendChild(linea);
    });
    historialBatalla.scrollTop = historialBatalla.scrollHeight;
}

function actualizarIndicador() {
    indicadorTurno.textContent = procesando ? "Turno rival..." : batalla?.estado === "en_curso" ? "Tu turno" : "";
    indicadorTurno.classList.toggle("rival", procesando);
}

function renderizarMovimientos(estado, habilitados = true) {
    const activo = pokemonActivo(estado, "jugador");
    movimientos.replaceChildren();
    const disponibles = activo?.movimientos || activo?.movimientos_disponibles || [];
    disponibles.slice(0, 4).forEach(movimiento => {
        const boton = document.createElement("button");
        boton.type = "button";
        boton.className = "movimiento";
        boton.disabled = !habilitados;
        boton.innerHTML = `<strong>${PokeMarket.escaparHTML(movimiento.nombre_mostrado || nombreMovimiento(movimiento.nombre))}</strong><small>${PokeMarket.escaparHTML(movimiento.tipo || "")} · ${Number(movimiento.potencia || 0)}</small>`;
        boton.addEventListener("click", () => ejecutarTurno(movimiento.nombre));
        movimientos.appendChild(boton);
    });
}

function seleccionarEquipo(id) {
    equipoSeleccionado = Number(id);
    tarjetasEquipos.querySelectorAll(".tarjeta-equipo").forEach(tarjeta => {
        tarjeta.classList.toggle("seleccionada", Number(tarjeta.dataset.id) === equipoSeleccionado);
    });
    iniciarBatalla.disabled = !equipoSeleccionado;
}

function renderizarTarjetasEquipos(equipos) {
    tarjetasEquipos.replaceChildren();
    equipos.forEach(equipo => {
        const tarjeta = document.createElement("button");
        tarjeta.type = "button";
        tarjeta.className = "tarjeta-equipo";
        tarjeta.dataset.id = equipo.id;
        tarjeta.disabled = Number(equipo.total_miembros) === 0;
        tarjeta.innerHTML = `<strong>${PokeMarket.escaparHTML(equipo.nombre)}</strong><span>${Number(equipo.total_miembros)} Pokémon</span><div class="miniaturas-equipo"></div>`;
        tarjeta.addEventListener("click", () => seleccionarEquipo(equipo.id));
        tarjetasEquipos.appendChild(tarjeta);
        PokeMarket.trainer(`/teams/${equipo.id}`).then(detalle => {
            const ids = detalle.equipo.miembros.map(miembro => miembro.pokemon_id);
            return PokeMarket.obtenerPokemonLote(ids, memoriaPokemonBatalla);
        }).then(memoria => {
            const miniaturas = tarjeta.querySelector(".miniaturas-equipo");
            memoria.forEach(pokemon => {
                const imagen = document.createElement("img");
                imagen.alt = pokemon.nombre;
                imagen.title = pokemon.nombre;
                PokeMarket.configurarImagen(imagen, pokemon);
                miniaturas.appendChild(imagen);
            });
        }).catch(() => {});
    });
}

function renderizarBatalla(estado) {
    batalla = estado;
    [ladoJugador, ladoRival].forEach(lado => lado.classList.remove("atacando", "impacto", "debilitado", "entrando"));
    renderizarLado(ladoJugador, estado, "jugador");
    renderizarLado(ladoRival, estado, "rival");
    renderizarMiniaturas(miniaturasJugador, estado.equipo_jugador.pokemon, estado.activo_jugador, "jugador");
    renderizarMiniaturas(miniaturasRival, estado.equipo_rival.pokemon, estado.activo_rival, "rival");
    renderizarHistorial(estado.historial);
    renderizarMovimientos(estado, estado.estado === "en_curso" && !procesando);
    numeroTurno.textContent = `Turno ${Number(estado.turno || 1)}`;
    turnoTexto.textContent = procesando ? "Turno rival" : estado.estado === "en_curso" ? "Tu turno" : "Batalla finalizada";
    actualizarIndicador();
}

function mostrarResultadoFinal(estado) {
    const finalizada = estado?.estado === "finalizada";
    resultadoBatalla.hidden = !finalizada;
    volverEquipos.hidden = !finalizada;
    abandonarBatalla.hidden = finalizada;
    if (finalizada) {
        resultadoBatalla.textContent = estado.resultado === "victoria" ? "¡Victoria!" : "Derrota";
        movimientos.replaceChildren();
    }
}

function buscarElementoPokemon(lado, id) {
    const contenedor = lado === "jugador" ? ladoJugador : ladoRival;
    return contenedor.querySelector(`[data-pokemon-id="${Number(id)}"]`);
}

function actualizarHp(lado, accion) {
    const elemento = buscarElementoPokemon(lado, accion.objetivo_id);
    if (!elemento) return;
    const fill = elemento.querySelector("[data-hp-fill]");
    const texto = elemento.querySelector("[data-hp-texto]");
    const porcentaje = Math.max(0, Math.min(100, accion.hp_nuevo / Math.max(1, accion.hp_maximo) * 100));
    if (fill) fill.style.width = `${porcentaje}%`;
    if (texto) texto.textContent = `${accion.hp_nuevo} / ${accion.hp_maximo} HP`;
}

function mostrarDano(lado, cantidad) {
    const contenedor = lado === "jugador" ? ladoJugador : ladoRival;
    const texto = document.createElement("span");
    texto.className = "dano-flotante";
    texto.textContent = `-${cantidad}`;
    contenedor.appendChild(texto);
    texto.addEventListener("animationend", () => texto.remove(), { once: true });
}

async function reproducirAtaque(accion) {
    const ladoAtacante = accion.actor;
    const ladoDefensor = accion.actor === "jugador" ? "rival" : "jugador";
    const atacante = ladoAtacante === "jugador" ? ladoJugador : ladoRival;
    const defensor = ladoDefensor === "jugador" ? ladoJugador : ladoRival;
    mensajeAccion.textContent = `${accion.pokemon_nombre} usó ${nombreMovimiento(accion.movimiento.nombre)}.`;
    ultimoMovimiento.textContent = accion.movimiento.nombre_mostrado || nombreMovimiento(accion.movimiento.nombre);
    atacante.classList.add("atacando");
    await esperar(380);
    atacante.classList.remove("atacando");
    defensor.classList.add("impacto");
    if (accion.danio > 0) mostrarDano(ladoDefensor, accion.danio);
    actualizarHp(ladoDefensor, accion);
    await esperar(450);
    defensor.classList.remove("impacto");
    efectividadTexto.textContent = accion.mensaje || "";
    mensajeAccion.textContent = accion.mensaje || `${accion.danio} puntos de daño.`;
    await esperar(550);
}

async function reproducirAcciones(acciones, estadoFinal) {
    for (const accion of acciones || []) {
        if (accion.tipo === "ataque") {
            await reproducirAtaque(accion);
        } else if (accion.tipo === "salida") {
            mensajeAccion.textContent = accion.mensaje;
            await esperar(400);
        } else if (accion.tipo === "debilitamiento") {
            const lado = accion.lado === "jugador" ? ladoJugador : ladoRival;
            lado.classList.add("debilitado");
            mensajeAccion.textContent = accion.mensaje;
            await esperar(650);
        } else if (accion.tipo === "entrada") {
            mensajeAccion.textContent = `${accion.pokemon_nombre} entra al combate.`;
            await esperar(250);
            renderizarBatalla(estadoFinal);
            const lado = accion.lado === "jugador" ? ladoJugador : ladoRival;
            lado.classList.add("entrando");
            await esperar(550);
            lado.classList.remove("entrando");
        }
    }
}

async function ejecutarTurno(movimiento) {
    if (!batalla || procesando || batalla.estado !== "en_curso") return;
    procesando = true;
    renderizarMovimientos(batalla, false);
    actualizarIndicador();
    try {
        const respuesta = await PokeMarket.trainer(`/battles/${batalla.id}/turn`, {
            method: "POST",
            body: { movimiento }
        });
        await reproducirAcciones(respuesta.acciones, respuesta.estado_final);
        mensajeAccion.textContent = "";
        renderizarBatalla(respuesta.estado_final);
        mostrarResultadoFinal(respuesta.estado_final);
    } catch (error) {
        mensajeAccion.textContent = error.message;
        renderizarMovimientos(batalla, true);
    } finally {
        procesando = false;
        if (batalla) renderizarBatalla(batalla);
        mostrarResultadoFinal(batalla);
    }
}

async function cambiarPokemon(pokemonId) {
    if (!batalla || procesando || batalla.estado !== "en_curso") return;
    procesando = true;
    renderizarMovimientos(batalla, false);
    actualizarIndicador();
    try {
        const respuesta = await PokeMarket.trainer(`/battles/${batalla.id}/switch`, {
            method: "POST",
            body: { pokemon_id: pokemonId }
        });
        await reproducirAcciones(respuesta.acciones, respuesta.estado_final);
        renderizarBatalla(respuesta.estado_final);
        mostrarResultadoFinal(respuesta.estado_final);
    } catch (error) {
        mensajeAccion.textContent = error.message;
    } finally {
        procesando = false;
        if (batalla) renderizarBatalla(batalla);
        mostrarResultadoFinal(batalla);
    }
}

async function cargarEquipos() {
    try {
        await PokeMarket.iniciarSesion();
        const respuesta = await PokeMarket.trainer("/teams");
        renderizarTarjetasEquipos(respuesta.equipos);
        if (respuesta.equipos.length === 0 || respuesta.equipos.every(equipo => Number(equipo.total_miembros) === 0)) {
            mostrarMensaje("Necesitas un equipo con al menos un Pokémon para combatir.", true);
            iniciarBatalla.disabled = true;
        }
    } catch (error) {
        mostrarMensaje(error.message, true);
        iniciarBatalla.disabled = true;
    }
    try {
        const activa = await PokeMarket.trainer("/battles/current");
        if (activa.batalla) {
            batallaActiva.hidden = false;
            iniciarBatalla.disabled = true;
            continuarBatalla.onclick = () => continuar(activa.batalla.id);
            abandonarDesdeInicio.onclick = () => abandonarActiva(activa.batalla.id);
        }
    } catch (error) {
        if (error.status !== 401) mostrarMensaje(error.message, true);
    }
}

async function continuar(id) {
    try {
        const respuesta = await PokeMarket.trainer(`/battles/${id}`);
        panelInicio.hidden = true;
        panelCombate.hidden = false;
        renderizarBatalla(respuesta.batalla);
    } catch (error) {
        mostrarMensaje(error.message, true);
    }
}

async function abandonarActiva(id) {
    try {
        await PokeMarket.trainer(`/battles/${id}`, { method: "DELETE" });
        batallaActiva.hidden = true;
        iniciarBatalla.disabled = false;
        mostrarMensaje("La batalla fue abandonada.");
    } catch (error) {
        mostrarMensaje(error.message, true);
    }
}

async function comenzarBatalla() {
    if (!equipoSeleccionado || procesando) return;
    iniciarBatalla.disabled = true;
    mostrarMensaje("Generando equipo rival...");
    try {
        const respuesta = await PokeMarket.trainer("/battles", {
            method: "POST",
            body: { equipo_id: equipoSeleccionado }
        });
        panelInicio.hidden = true;
        panelCombate.hidden = false;
        resultadoBatalla.hidden = true;
        renderizarBatalla(respuesta.batalla);
        mostrarMensaje("");
    } catch (error) {
        mostrarMensaje(error.message, true);
        iniciarBatalla.disabled = false;
    }
}

async function abandonar() {
    if (!batalla || !window.confirm("¿Abandonar la batalla?")) return;
    abandonarBatalla.disabled = true;
    try {
        await PokeMarket.trainer(`/battles/${batalla.id}`, { method: "DELETE" });
        window.location.href = "equipos.php";
    } catch (error) {
        mensajeAccion.textContent = error.message;
        abandonarBatalla.disabled = false;
    }
}

iniciarBatalla.addEventListener("click", comenzarBatalla);
abandonarBatalla.addEventListener("click", abandonar);
cargarEquipos();
