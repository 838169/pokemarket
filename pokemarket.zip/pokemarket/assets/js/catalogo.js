const grid = document.getElementById("pokemonGrid");
const totalPokemon = document.getElementById("totalPokemon");
const modalColeccion = document.getElementById("modalColeccion");
const cargarMas = document.getElementById("cargarMas");
const buscarPokemon = document.getElementById("buscarPokemon");
const botonBuscar = document.getElementById("botonBuscar");
const limpiarBusqueda = document.getElementById("limpiarBusqueda");
const coleccionIds = new Set();
const guardandoIds = new Set();
const limite = 12;
let offset = 0;
let totalDisponible = 0;
let cargandoPokemon = false;
let pokemonSeleccionado = null;
let vistaActual = 0;
let detalleActual = 0;
let listo = false;

function sincronizarBotones() {
    document.querySelectorAll(".btn-collection").forEach(boton => {
        const id = Number(boton.dataset.id);
        const guardado = coleccionIds.has(id);
        boton.disabled = guardado || guardandoIds.has(id);
        boton.classList.toggle("saved", guardado);
        boton.textContent = guardado ? "✓ En colección" : guardandoIds.has(id) ? "Guardando..." : "+ Colección";
    });
    if (pokemonSeleccionado) {
        const id = Number(pokemonSeleccionado.id);
        const guardado = coleccionIds.has(id);
        modalColeccion.disabled = guardado || guardandoIds.has(id);
        modalColeccion.classList.toggle("saved", guardado);
        modalColeccion.textContent = guardado ? "✓ Guardado en tu colección"
            : guardandoIds.has(id) ? "Guardando..." : "+ Agregar a mi colección";
    }
}

function crearPokemonCard(pokemon) {
    const card = document.createElement("article");
    card.className = "pokemon-card";
    card.style.setProperty("--pokemon-glow", PokeMarket.colorTipo(pokemon.tipos[0]));
    card.innerHTML = `
        <span class="pokemon-number">#${String(pokemon.id).padStart(3, "0")}</span>
        <h2 class="pokemon-name">${PokeMarket.escaparHTML(pokemon.nombre)}</h2>
        <div class="pokemon-image"><img loading="lazy" decoding="async" alt=""></div>
        <div class="pokemon-types">${pokemon.tipos.map(tipo =>
            `<span class="type-badge">${PokeMarket.escaparHTML(tipo)}</span>`).join("")}</div>
        <div class="pokemon-actions">
            <button class="btn-card" type="button">Ver detalles</button>
            <button class="btn-card btn-collection" type="button" data-id="${Number(pokemon.id)}">+ Colección</button>
        </div>`;
    PokeMarket.configurarImagen(card.querySelector("img"), pokemon);
    const detalle = card.querySelector(".btn-card:not(.btn-collection)");
    detalle.addEventListener("click", () => abrirDetalle(pokemon.id, detalle));
    card.querySelector(".btn-collection").addEventListener("click", () => agregarColeccion(pokemon.id));
    return card;
}

async function cargarPokemon(reiniciar = false) {
    if (cargandoPokemon && !reiniciar) return;
    const vista = ++vistaActual;
    cargandoPokemon = true;
    cargarMas.disabled = true;
    cargarMas.textContent = "Cargando...";
    if (reiniciar) {
        offset = 0;
        grid.innerHTML = '<div class="loading">Cargando Pokémon...</div>';
    }
    try {
        const resultado = await PokeMarket.pokemon(`/pokemon?limit=${limite}&offset=${offset}`);
        if (vista !== vistaActual) return;
        totalDisponible = Number(resultado.total);
        totalPokemon.textContent = totalDisponible;
        if (reiniciar) grid.replaceChildren();
        resultado.pokemon.forEach(pokemon => grid.appendChild(crearPokemonCard(pokemon)));
        offset += resultado.pokemon.length;
        cargarMas.style.display = offset >= totalDisponible ? "none" : "";
        sincronizarBotones();
    } catch (error) {
        if (vista !== vistaActual) return;
        if (reiniciar) grid.innerHTML = `<div class="loading">${PokeMarket.escaparHTML(error.message)}</div>`;
        else alert(error.message);
    } finally {
        if (vista === vistaActual) {
            cargandoPokemon = false;
            cargarMas.disabled = false;
            cargarMas.textContent = "Cargar más Pokémon";
        }
    }
}

async function abrirDetalle(id, boton) {
    const solicitud = ++detalleActual;
    boton.disabled = true;
    try {
        const resultado = await PokeMarket.pokemon(`/pokemon/${id}`);
        if (solicitud !== detalleActual) return;
        pokemonSeleccionado = resultado.pokemon;
        PokeMarket.mostrarDetalle(pokemonSeleccionado);
        sincronizarBotones();
    } catch (error) {
        if (solicitud === detalleActual) alert(error.message);
    } finally {
        boton.disabled = false;
    }
}

async function agregarColeccion(id) {
    id = Number(id);
    if (guardandoIds.has(id) || coleccionIds.has(id)) return;
    guardandoIds.add(id);
    sincronizarBotones();
    try {
        await PokeMarket.trainer("/collection", { method: "POST", body: { pokemon_id: id } });
        coleccionIds.add(id);
    } catch (error) {
        if (error.data?.already_exists) coleccionIds.add(id);
        else alert(error.message);
    } finally {
        guardandoIds.delete(id);
        sincronizarBotones();
    }
}

async function ejecutarBusqueda() {
    const termino = buscarPokemon.value.trim();
    if (!listo || termino === "") return;
    const vista = ++vistaActual;
    cargandoPokemon = false;
    botonBuscar.disabled = true;
    botonBuscar.textContent = "...";
    cargarMas.style.display = "none";
    limpiarBusqueda.classList.add("visible");
    grid.innerHTML = '<div class="loading">Buscando Pokémon...</div>';
    try {
        const resultado = await PokeMarket.pokemon(`/pokemon/search?q=${encodeURIComponent(termino)}`);
        if (vista !== vistaActual) return;
        grid.replaceChildren(crearPokemonCard(resultado.pokemon));
        sincronizarBotones();
    } catch (error) {
        if (vista !== vistaActual) return;
        grid.innerHTML = `<div class="search-empty">${PokeMarket.escaparHTML(error.message)}</div>`;
    } finally {
        if (vista === vistaActual) {
            botonBuscar.disabled = false;
            botonBuscar.textContent = "Buscar";
        }
    }
}

function restaurarCatalogo() {
    if (!listo) return;
    buscarPokemon.value = "";
    limpiarBusqueda.classList.remove("visible");
    botonBuscar.disabled = false;
    botonBuscar.textContent = "Buscar";
    cargarMas.style.display = "";
    cargarPokemon(true);
}

modalColeccion.addEventListener("click", () => {
    if (pokemonSeleccionado) agregarColeccion(pokemonSeleccionado.id);
});
cargarMas.addEventListener("click", () => { if (listo) cargarPokemon(); });
botonBuscar.addEventListener("click", ejecutarBusqueda);
buscarPokemon.addEventListener("keydown", event => { if (event.key === "Enter") ejecutarBusqueda(); });
limpiarBusqueda.addEventListener("click", restaurarCatalogo);

async function iniciarCatalogo() {
    cargarMas.disabled = true;
    botonBuscar.disabled = true;
    try {
        await PokeMarket.iniciarSesion();
        const resultado = await PokeMarket.trainer("/collection");
        resultado.coleccion.forEach(item => coleccionIds.add(Number(item.pokemon_id)));
        listo = true;
        botonBuscar.disabled = false;
        await cargarPokemon(true);
    } catch (error) {
        grid.innerHTML = `<div class="loading">${PokeMarket.escaparHTML(error.message)}
            <button class="btn-card" type="button">Reintentar</button></div>`;
        grid.querySelector("button").addEventListener("click", iniciarCatalogo, { once: true });
    }
}

iniciarCatalogo();
