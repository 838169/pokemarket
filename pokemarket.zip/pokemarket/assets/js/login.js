const formulario = document.getElementById("formLogin");
const mensaje = document.getElementById("mensaje");
const boton = formulario.querySelector('button[type="submit"]');

formulario.addEventListener("submit", async function (event) {
    event.preventDefault();
    if (boton.disabled) return;

    boton.disabled = true;
    mensaje.className = "form-message";
    mensaje.textContent = "";

    try {
        const resultado = await PokeMarket.trainer("/auth/login", {
            method: "POST",
            body: {
                email: document.getElementById("email").value.trim(),
                password: document.getElementById("password").value
            }
        });

        mensaje.textContent = resultado.message;
        mensaje.classList.add("success");
        await new Promise(resolve => setTimeout(resolve, 700));
        window.location.href = "catalogo.php";
    } catch (error) {
        mensaje.textContent = error.message || "No fue posible conectar con el servidor.";
        mensaje.classList.add("error");
    } finally {
        boton.disabled = false;
    }
});
