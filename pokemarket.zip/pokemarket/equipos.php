<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis equipos | PokéMarket</title>
    <link rel="stylesheet" href="assets/css/base.css">
    <link rel="stylesheet" href="assets/css/catalogo.css">
    <link rel="stylesheet" href="assets/css/equipos.css">
</head>

<body class="catalog-page" data-protegida="true">
    <header class="catalog-header">
        <div class="brand">
            <div class="brand-ball"></div>
            <div class="brand-name">
                <span class="brand-poke">Poké</span><span class="brand-market">Market</span>
            </div>
        </div>

        <nav class="catalog-nav">
            <a href="catalogo.php">Catálogo</a>
            <a href="coleccion.php">Mi colección</a>
            <a href="equipos.php" class="active">Mis equipos</a>
        </nav>

        <div class="catalog-user">
            <div id="usuarioAvatar" class="user-avatar"></div>
            <span id="usuarioNombre"></span>
            <a id="cerrarSesion" href="login.php" class="logout-link">Salir</a>
        </div>
    </header>

    <main class="equipos-container">
        <section class="equipos-heading">
            <div>
                <h1>Mis equipos</h1>
                <p>Crea equipos y organiza hasta seis Pokémon en cada uno.</p>
            </div>
            <div class="equipos-actions">
                <form id="formEquipo" class="crear-equipo">
                    <input id="nombreEquipo" type="text" maxlength="100" placeholder="Nombre del equipo" required>
                    <button type="submit">Crear equipo</button>
                </form>
                <button id="botonBatallaEquipo" class="btn-batalla" type="button">Batalla</button>
            </div>
        </section>

        <div id="mensajeEquipos" class="equipos-mensaje" aria-live="polite"></div>

        <section class="equipos-layout">
            <aside id="listaEquipos" class="lista-equipos">
                <div class="loading">Cargando equipos...</div>
            </aside>

            <section id="detalleEquipo" class="detalle-equipo">
                <div class="empty-equipo">
                    <h2>Selecciona un equipo</h2>
                    <p>Crea o selecciona un equipo para organizar tu colección.</p>
                </div>
            </section>
        </section>
    </main>

    <div id="pokemonModal" class="pokemon-modal">
        <div class="modal-backdrop"></div>
        <section class="pokemon-detail">
            <button id="cerrarModal" class="modal-close" type="button">×</button>
            <div class="detail-image-area"><img id="detalleImagen" src="" alt=""></div>
            <div class="detail-info">
                <span id="detalleNumero" class="detail-number"></span>
                <h2 id="detalleNombre"></h2>
                <div id="detalleTipos" class="detail-types"></div>
                <p id="detalleDescripcion" class="detail-description"></p>
                <div class="detail-stats">
                    <div class="detail-stat"><span>Altura</span><strong id="detalleAltura"></strong></div>
                    <div class="detail-stat"><span>Peso</span><strong id="detallePeso"></strong></div>
                </div>
                <h3>Habilidades</h3>
                <div id="detalleHabilidades" class="detail-abilities"></div>
            </div>
        </section>
    </div>

    <script src="assets/js/api.js"></script>
    <script src="assets/js/equipos.js"></script>
    <script>
        PokeMarket.trainer("/battles/current").then(respuesta => {
            const boton = document.getElementById("botonBatallaEquipo");
            boton.textContent = respuesta.batalla ? "Continuar batalla" : "Batalla";
        }).catch(() => {});
        document.getElementById("botonBatallaEquipo").addEventListener("click", () => { window.location.href = "batalla.php"; });
    </script>
</body>

</html>
