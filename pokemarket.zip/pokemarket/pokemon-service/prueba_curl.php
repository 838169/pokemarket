<?php

$ch = curl_init("https://pokeapi.co/api/v2/pokemon/25");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);

var_dump(curl_errno($ch));
var_dump(curl_error($ch));
var_dump(curl_getinfo($ch, CURLINFO_HTTP_CODE));

curl_close($ch);
