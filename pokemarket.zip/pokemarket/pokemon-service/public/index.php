<?php

declare(strict_types=1);

use PokemonService\Controllers\PokemonController;
use PokemonService\Exceptions\HttpException;
use PokemonService\Http\JsonResponse;
use PokemonService\Services\CacheService;
use PokemonService\Services\PokeApiClient;
use PokemonService\Services\PokemonMapper;
use PokemonService\Services\SpriteResolver;

$config = require dirname(__DIR__) . '/bootstrap.php';

try {
    $controller = new PokemonController(
        new PokeApiClient(
            $config['pokeapi_base_url'],
            $config['http_timeout'],
            new CacheService($config['cache_path'], $config['cache_ttl'])
        ),
        new PokemonMapper(new SpriteResolver()),
        new CacheService($config['cache_path'], $config['cache_ttl']),
        $config
    );

    $router = require dirname(__DIR__) . '/src/Routes/api.php';
    [$statusCode, $payload] = $router($controller);

    if ($statusCode === 204) {
        http_response_code(204);
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        exit;
    }

    JsonResponse::send($payload, $statusCode);
} catch (HttpException $exception) {
    JsonResponse::send(array_merge([
        'success' => false,
        'message' => $exception->getMessage(),
    ], $exception->context()), $exception->statusCode());
} catch (Throwable $exception) {
    error_log($exception->getMessage());
    JsonResponse::send([
        'success' => false,
        'message' => 'Error interno del pokemon-service',
    ], 500);
}
