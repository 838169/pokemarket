<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Batalla | PokéMarket</title>
    <link rel="stylesheet" href="assets/css/base.css">
    <link rel="stylesheet" href="assets/css/catalogo.css">
    <link rel="stylesheet" href="assets/css/batalla.css">
</head>

<body class="catalog-page" data-protegida="true">
    <header class="catalog-header">
        <div class="brand">
            <div class="brand-ball"></div>
            <div class="brand-name"><span class="brand-poke">Poké</span><span class="brand-market">Market</span></div>
        </div>
        <nav class="catalog-nav">
            <a href="catalogo.php">Catálogo</a>
            <a href="coleccion.php">Mi colección</a>
            <a href="equipos.php">Mis equipos</a>
            <a href="batalla.php" class="active">Batalla</a>
        </nav>
        <div class="catalog-user">
            <div id="usuarioAvatar" class="user-avatar"></div>
            <span id="usuarioNombre"></span>
            <a id="cerrarSesion" href="login.php" class="logout-link">Salir</a>
        </div>
    </header>

    <main class="batalla-container">
        <section class="batalla-heading">
            <div>
                <h1>Batalla Pokémon</h1>
                <p>Elige un equipo y combate por turnos.</p>
            </div>
            <a class="btn-volver" href="equipos.php">Mis equipos</a>
        </section>

        <section id="panelInicio" class="panel-batalla panel-inicio">
            <p class="selector-titulo">Selecciona un equipo para la batalla</p>
            <div id="tarjetasEquipos" class="tarjetas-equipos"></div>
            <div class="inicio-controles">
                <button id="iniciarBatalla" class="btn-batalla" type="button" disabled>Comenzar batalla</button>
            </div>
            <div id="batallaActiva" class="batalla-activa" hidden>
                <p>Hay una batalla activa en tu sesión.</p>
                <button id="continuarBatalla" class="btn-batalla" type="button">Continuar batalla</button>
                <button id="abandonarDesdeInicio" class="btn-abandonar" type="button">Abandonar batalla</button>
            </div>
            <p id="mensajeBatalla" class="mensaje-batalla" aria-live="polite"></p>
        </section>

        <section id="panelCombate" class="panel-combate" hidden>
            <div class="combate-campo">
                <article id="ladoJugador" class="lado-combate lado-jugador"></article>
                <div class="zona-central">
                    <strong class="versus">VS</strong>
                    <span id="numeroTurno">Turno 1</span>
                    <span id="turnoTexto">Tu turno</span>
                    <span id="ultimoMovimiento"></span>
                    <span id="efectividadTexto"></span>
                </div>
                <article id="ladoRival" class="lado-combate lado-rival"></article>
            </div>
            <div class="equipos-miniaturas">
                <div><h3>Tu equipo</h3><div id="miniaturasJugador" class="miniaturas"></div></div>
                <div><h3>Equipo rival</h3><div id="miniaturasRival" class="miniaturas"></div></div>
            </div>
            <div id="mensajeAccion" class="mensaje-accion" aria-live="polite"></div>
            <div id="indicadorTurno" class="indicador-turno"></div>
            <div id="historialBatalla" class="historial-batalla"></div>
            <div id="movimientos" class="movimientos"></div>
            <div id="resultadoBatalla" class="resultado-batalla" hidden></div>
            <a id="volverEquipos" class="btn-batalla" href="equipos.php" hidden>Volver a Mis equipos</a>
            <button id="abandonarBatalla" class="btn-abandonar" type="button">Abandonar batalla</button>
        </section>
    </main>

    <script src="assets/js/api.js"></script>
    <script src="assets/js/batalla.js"></script>
</body>

</html>
